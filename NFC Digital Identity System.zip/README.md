# EventConnect - NFC Event Management & Social Network

A comprehensive event management and social networking platform with NFC/QR code functionality for seamless check-ins and networking.

## Sample Ndebele Zimbabwean Names

When creating test accounts, consider using authentic Ndebele names:
- Thabo Ndlovu
- Lindiwe Moyo
- Sipho Ncube
- Nomvula Dube
- Mpilo Khumalo
- Zanele Nkomo
- Siyabonga Mthethwa
- Thandiwe Sibanda
- Busisiwe Gumede

## Features

### User Roles
- **User**: Can view/register for events, join forums, post content, and network with others
- **Admin**: Can create and manage events, track live attendance, and access event analytics
- **System Manager**: Has access to all events, can manage users, and verify documents

### Core Functionality

#### Event Management
- Create and manage events with details (name, date, location, capacity)
- Event registration system
- NFC/QR code check-in/check-out for attendance tracking
- Real-time attendance analytics
- Auto-created event forums for registered attendees

#### Social Networking
- User profiles with biography, employment, research area
- Follow/unfollow other users
- Direct messaging between users
- Social feed for sharing posts
- Like and comment on posts

#### Forums & Communities
- Create and join forums
- Event-specific forums (auto-created with events)
- Independent community forums
- Post and engage in discussions

#### NFC/QR Code System
- **Event Check-in**: Admins scan attendee badges to check them in/out
- **Networking**: Users scan each other's badges to view profiles
- QR code generation for each user
- Attendance tracking with scanner name and timestamp

#### Document Verification
- Upload qualifications and certificates
- System manager reviews and verifies documents
- Verified documents appear on user profiles

#### Search & Discovery
- Search for events by name or description
- Search for forums by name or description
- Browse all users (system manager only)

## User Guide

### Getting Started
1. **Sign Up**: Create an account and select your role (User/Admin/System Manager)
2. **Complete Profile**: Add your biography, employment, and research area
3. **Upload Documents**: Add qualifications for verification (optional)

### For Regular Users
- Browse events and register
- Join forums and participate in discussions
- Follow other users and build your network
- Share posts on the social feed
- Send messages to other users
- Scan others' QR codes to view their profiles

### For Event Admins
- Create events from the Events page
- Manage your events and track registrations
- Scan attendee QR codes to check them in/out
- View live analytics at `/admin`
- Access event-specific forums

### For System Managers
- Access admin panel at `/system-manager`
- View all users and events
- Verify uploaded documents
- Manage the entire platform

## Technical Details

### NFC/QR Code Usage

#### Generating Your QR Code
Your QR code is automatically generated and available at `/scan`. Share this code with:
- Event staff for check-in
- Other attendees for networking

#### Scanning
1. Go to `/scan`
2. Select scan mode:
   - **Event Check-in**: Select event, paste user ID from their QR
   - **Networking**: Paste user ID to view their profile

#### Check-in Flow
- First scan: Checks user in, joins event forum
- Second scan: Checks user out
- Third scan: Checks user back in
- All scans are logged with timestamp and scanner name

## Sample Users

For testing, you can create accounts with different roles:
- Role: `user` - Basic user access
- Role: `admin` - Event creator access
- Role: `system_manager` - Full system access

## Data Structure

All data is stored in Supabase:
- **Users**: Profiles, followers, qualifications
- **Events**: Details, registrations, attendance
- **Forums**: Communities, members, posts
- **Messages**: Direct conversations
- **Documents**: Uploaded files with verification status
- **Attendance**: Check-in/out records

## Notes

- Email confirmation is auto-enabled since no email server is configured
- Documents are stored in Supabase Storage
- QR codes encode user IDs in JSON format
- The system uses a blue and white color theme