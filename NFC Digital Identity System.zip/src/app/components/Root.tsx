import { Outlet, Link, useNavigate, useLocation } from 'react-router';
import { AuthProvider, useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useState, useEffect } from 'react';
import { 
  Home, 
  Calendar, 
  Users, 
  MessageSquare, 
  QrCode, 
  User, 
  LogOut,
  BarChart3,
  Settings
} from 'lucide-react';
import { toast } from 'sonner';

function RootContent() {
  const { user, signIn, signUp, signOut, isLoading } = useAuth();
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [authTab, setAuthTab] = useState<'signin' | 'signup'>('signin');
  const navigate = useNavigate();
  const location = useLocation();

  // Sign in form
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');

  // Sign up form
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpFullName, setSignUpFullName] = useState('');
  const [signUpRole, setSignUpRole] = useState('user');

  useEffect(() => {
    if (!isLoading && !user && location.pathname !== '/') {
      setShowAuthDialog(true);
    }
  }, [user, isLoading, location.pathname]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signIn(signInEmail, signInPassword);
      setShowAuthDialog(false);
      toast.success('Signed in successfully!');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signUp(signUpEmail, signUpPassword, signUpFullName, signUpRole);
      setShowAuthDialog(false);
      toast.success('Account created successfully!');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleSignOut = () => {
    signOut();
    navigate('/');
    toast.success('Signed out successfully');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-blue-600 text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className="border-b border-blue-100 bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <Link to="/" className="text-2xl font-bold text-blue-600">
                EventConnect
              </Link>
              
              {user && (
                <div className="hidden md:flex items-center space-x-6">
                  <Link 
                    to="/" 
                    className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition"
                  >
                    <Home className="w-5 h-5" />
                    <span>Home</span>
                  </Link>
                  <Link 
                    to="/events" 
                    className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition"
                  >
                    <Calendar className="w-5 h-5" />
                    <span>Events</span>
                  </Link>
                  <Link 
                    to="/forums" 
                    className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition"
                  >
                    <Users className="w-5 h-5" />
                    <span>Forums</span>
                  </Link>
                  <Link 
                    to="/messages" 
                    className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition"
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span>Messages</span>
                  </Link>
                  <Link 
                    to="/scan" 
                    className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition"
                  >
                    <QrCode className="w-5 h-5" />
                    <span>Scan</span>
                  </Link>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-4">
              {user ? (
                <>
                  {user.role === 'admin' && (
                    <Button
                      variant="ghost"
                      onClick={() => navigate('/admin')}
                      className="text-gray-700 hover:text-blue-600"
                    >
                      <BarChart3 className="w-5 h-5 mr-2" />
                      Analytics
                    </Button>
                  )}
                  {user.role === 'system_manager' && (
                    <Button
                      variant="ghost"
                      onClick={() => navigate('/system-manager')}
                      className="text-gray-700 hover:text-blue-600"
                    >
                      <Settings className="w-5 h-5 mr-2" />
                      Admin Panel
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    onClick={() => navigate(`/profile/${user.id}`)}
                    className="text-gray-700 hover:text-blue-600"
                  >
                    <User className="w-5 h-5 mr-2" />
                    {user.fullName}
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={handleSignOut}
                    className="text-gray-700 hover:text-red-600"
                  >
                    <LogOut className="w-5 h-5" />
                  </Button>
                </>
              ) : (
                <Button onClick={() => setShowAuthDialog(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        <Outlet />
      </main>

      {/* Auth Dialog */}
      <Dialog open={showAuthDialog} onOpenChange={setShowAuthDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-blue-600">Welcome to EventConnect</DialogTitle>
            <DialogDescription className="text-gray-500">Manage your events and forums with ease.</DialogDescription>
          </DialogHeader>
          
          <Tabs value={authTab} onValueChange={(v) => setAuthTab(v as any)}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Sign In</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
            </TabsList>
            
            <TabsContent value="signin">
              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <Label htmlFor="signin-email">Email</Label>
                  <Input
                    id="signin-email"
                    type="email"
                    value={signInEmail}
                    onChange={(e) => setSignInEmail(e.target.value)}
                    placeholder="thabo@example.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="signin-password">Password</Label>
                  <Input
                    id="signin-password"
                    type="password"
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  Sign In
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="signup">
              <form onSubmit={handleSignUp} className="space-y-4">
                <div>
                  <Label htmlFor="signup-name">Full Name</Label>
                  <Input
                    id="signup-name"
                    type="text"
                    value={signUpFullName}
                    onChange={(e) => setSignUpFullName(e.target.value)}
                    placeholder="Thabo Ndlovu"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    placeholder="thabo@example.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="signup-password">Password</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    value={signUpPassword}
                    onChange={(e) => setSignUpPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="signup-role">Role</Label>
                  <Select value={signUpRole} onValueChange={setSignUpRole}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">User</SelectItem>
                      <SelectItem value="admin">Event Admin</SelectItem>
                      <SelectItem value="system_manager">System Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  Sign Up
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function Root() {
  return (
    <AuthProvider>
      <RootContent />
    </AuthProvider>
  );
}