import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Calendar, MapPin, Users, Search, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function Events() {
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [events, setEvents] = useState<any[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  // Create event form
  const [eventName, setEventName] = useState('');
  const [eventDescription, setEventDescription] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventLocation, setEventLocation] = useState('');
  const [eventCapacity, setEventCapacity] = useState('');

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    fetchEvents();
  }, []);

  useEffect(() => {
    if (searchQuery.trim()) {
      searchEvents(searchQuery);
    } else {
      setFilteredEvents(events);
    }
  }, [searchQuery, events]);

  const fetchEvents = async () => {
    try {
      const response = await fetch(`${baseUrl}/events`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const data = await response.json();
      setEvents(data.events || []);
      setFilteredEvents(data.events || []);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const searchEvents = async (query: string) => {
    try {
      const response = await fetch(`${baseUrl}/search/events?q=${encodeURIComponent(query)}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const data = await response.json();
      setFilteredEvents(data.events || []);
    } catch (error) {
      console.error('Error searching events:', error);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);

    try {
      const response = await fetch(`${baseUrl}/events`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          name: eventName,
          description: eventDescription,
          date: eventDate,
          location: eventLocation,
          capacity: parseInt(eventCapacity) || 0,
        }),
      });

      if (response.ok) {
        toast.success('Event created successfully!');
        setShowCreateDialog(false);
        resetForm();
        fetchEvents();
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to create event');
      }
    } catch (error) {
      console.error('Error creating event:', error);
      toast.error('Failed to create event');
    } finally {
      setIsCreating(false);
    }
  };

  const handleRegister = async (eventId: string) => {
    try {
      const response = await fetch(`${baseUrl}/events/${eventId}/register`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        toast.success('Registered successfully!');
        fetchEvents();
      } else {
        toast.error('Failed to register');
      }
    } catch (error) {
      console.error('Error registering:', error);
      toast.error('Failed to register');
    }
  };

  const resetForm = () => {
    setEventName('');
    setEventDescription('');
    setEventDate('');
    setEventLocation('');
    setEventCapacity('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Events</h1>
            <p className="text-gray-600">Discover and join upcoming events</p>
          </div>
          
          {user && (
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white mt-4 md:mt-0">
                  <Plus className="w-5 h-5 mr-2" />
                  Create Event
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-blue-600">Create New Event</DialogTitle>
                  <DialogDescription className="text-gray-500">Fill in the details to create a new event.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateEvent} className="space-y-4">
                  <div>
                    <Label htmlFor="event-name">Event Name</Label>
                    <Input
                      id="event-name"
                      value={eventName}
                      onChange={(e) => setEventName(e.target.value)}
                      placeholder="Annual Tech Conference"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="event-description">Description</Label>
                    <Textarea
                      id="event-description"
                      value={eventDescription}
                      onChange={(e) => setEventDescription(e.target.value)}
                      placeholder="Describe your event..."
                      className="min-h-[100px]"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="event-date">Date & Time</Label>
                      <Input
                        id="event-date"
                        type="datetime-local"
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="event-capacity">Capacity</Label>
                      <Input
                        id="event-capacity"
                        type="number"
                        value={eventCapacity}
                        onChange={(e) => setEventCapacity(e.target.value)}
                        placeholder="100"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="event-location">Location</Label>
                    <Input
                      id="event-location"
                      value={eventLocation}
                      onChange={(e) => setEventLocation(e.target.value)}
                      placeholder="Harare International Conference Centre"
                      required
                    />
                  </div>
                  <div className="flex justify-end space-x-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowCreateDialog(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={isCreating}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {isCreating ? 'Creating...' : 'Create Event'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search events..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-blue-100 focus:border-blue-300"
            />
          </div>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((event) => {
            const isRegistered = user && event.registeredUsers?.includes(user.id);
            const isFull = event.registeredUsers?.length >= event.capacity;
            
            return (
              <Card 
                key={event.id} 
                className="bg-white border-blue-100 hover:shadow-lg transition cursor-pointer"
                onClick={() => navigate(`/events/${event.id}`)}
              >
                <CardHeader>
                  <CardTitle className="text-blue-600">{event.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4 line-clamp-3">{event.description}</p>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2 text-blue-600" />
                      {new Date(event.date).toLocaleString()}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-2 text-blue-600" />
                      {event.location}
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2 text-blue-600" />
                      {event.registeredUsers?.length || 0} / {event.capacity} registered
                    </div>
                  </div>

                  {user && (
                    <div className="mt-4">
                      {isRegistered ? (
                        <Button 
                          className="w-full bg-green-600 hover:bg-green-700 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                          }}
                          disabled
                        >
                          Registered ✓
                        </Button>
                      ) : isFull ? (
                        <Button 
                          className="w-full bg-gray-400 text-white"
                          disabled
                        >
                          Event Full
                        </Button>
                      ) : (
                        <Button 
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRegister(event.id);
                          }}
                        >
                          Register
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredEvents.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No events found</h3>
            <p className="text-gray-500">
              {searchQuery ? 'Try a different search term' : 'Be the first to create an event!'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}