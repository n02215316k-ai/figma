import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { projectId } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  User, 
  Briefcase, 
  GraduationCap, 
  FileText, 
  UserPlus, 
  UserMinus, 
  MessageCircle,
  Upload,
  CheckCircle
} from 'lucide-react';
import { toast } from 'sonner';

export default function Profile() {
  const { id } = useParams();
  const { user: currentUser, accessToken, updateUser } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [showDocumentDialog, setShowDocumentDialog] = useState(false);

  // Edit form
  const [editBiography, setEditBiography] = useState('');
  const [editEmployment, setEditEmployment] = useState('');
  const [editResearch, setEditResearch] = useState('');

  // Document upload
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [documentType, setDocumentType] = useState('qualification');
  const [isUploading, setIsUploading] = useState(false);

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;
  const isOwnProfile = currentUser?.id === id;

  useEffect(() => {
    if (id) {
      fetchProfile();
    } else if (currentUser) {
      // If no ID provided, use current user's ID
      navigate(`/profile/${currentUser.id}`, { replace: true });
    }
  }, [id, currentUser]);

  const fetchProfile = async () => {
    try {
      console.log('Fetching profile for ID:', id);
      console.log('Access token available:', !!accessToken);
      console.log('Current user ID:', currentUser?.id);
      
      const response = await fetch(`${baseUrl}/users/${id}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      
      console.log('Response status:', response.status);
      const data = await response.json();
      console.log('Profile data received:', data);
      
      if (data.user) {
        setProfile(data.user);
        setEditBiography(data.user.biography || '');
        setEditEmployment(data.user.currentEmployment || '');
        setEditResearch(data.user.researchArea || '');
        setIsFollowing(data.user.followers?.includes(currentUser?.id || ''));
      } else {
        console.error('No user data in response:', data);
        toast.error('Profile not found');
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast.error('Failed to load profile');
    }
  };

  const handleUpdateProfile = async () => {
    try {
      const response = await fetch(`${baseUrl}/users/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          biography: editBiography,
          currentEmployment: editEmployment,
          researchArea: editResearch,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setProfile(data.user);
        updateUser(data.user);
        setIsEditing(false);
        toast.success('Profile updated!');
      } else {
        toast.error('Failed to update profile');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    }
  };

  const handleFollow = async () => {
    try {
      const endpoint = isFollowing 
        ? `${baseUrl}/users/${id}/follow`
        : `${baseUrl}/users/${id}/follow`;
      
      const response = await fetch(endpoint, {
        method: isFollowing ? 'DELETE' : 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        setIsFollowing(!isFollowing);
        fetchProfile();
        toast.success(isFollowing ? 'Unfollowed' : 'Following!');
      }
    } catch (error) {
      console.error('Error following:', error);
    }
  };

  const handleDocumentUpload = async () => {
    if (!documentFile) {
      toast.error('Please select a file');
      return;
    }

    setIsUploading(true);
    try {
      // Convert file to base64
      const reader = new FileReader();
      reader.readAsDataURL(documentFile);
      reader.onloadend = async () => {
        const base64String = reader.result?.toString().split(',')[1];
        
        const response = await fetch(`${baseUrl}/documents`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            fileName: documentFile.name,
            fileData: base64String,
            fileType: documentFile.type,
            documentType,
          }),
        });

        if (response.ok) {
          toast.success('Document uploaded successfully!');
          setShowDocumentDialog(false);
          setDocumentFile(null);
          fetchProfile();
        } else {
          const error = await response.json();
          toast.error(error.error || 'Upload failed');
        }
        setIsUploading(false);
      };
    } catch (error) {
      console.error('Error uploading document:', error);
      toast.error('Upload failed');
      setIsUploading(false);
    }
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '??';
  };

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-blue-600 text-xl mb-4">Loading profile...</div>
          <p className="text-gray-500">
            Fetching profile for user ID: {id}
          </p>
          <p className="text-sm text-gray-400">
            If this takes too long, the profile may not exist or there may be a connection issue.
          </p>
          {currentUser && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg text-left max-w-md mx-auto">
              <p className="text-sm text-gray-600">
                <strong>Debug Info:</strong>
              </p>
              <p className="text-sm text-gray-600">Your ID: {currentUser.id}</p>
              <p className="text-sm text-gray-600">Viewing ID: {id}</p>
              <p className="text-sm text-gray-600">
                Is own profile: {currentUser.id === id ? 'Yes' : 'No'}
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="bg-white border-blue-100 mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
              <div className="flex items-center space-x-6 mb-4 md:mb-0">
                <Avatar className="w-24 h-24">
                  <AvatarFallback className="bg-blue-600 text-white text-3xl">
                    {getInitials(profile.fullName)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">{profile.fullName}</h1>
                  <p className="text-gray-600">{profile.email}</p>
                  <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                    <div>
                      <span className="font-semibold">{profile.followers?.length || 0}</span> Followers
                    </div>
                    <div>
                      <span className="font-semibold">{profile.following?.length || 0}</span> Following
                    </div>
                  </div>
                </div>
              </div>

              {!isOwnProfile && currentUser && (
                <div className="flex space-x-3">
                  <Button
                    onClick={handleFollow}
                    className={isFollowing 
                      ? "bg-gray-500 hover:bg-gray-600 text-white"
                      : "bg-blue-600 hover:bg-blue-700 text-white"
                    }
                  >
                    {isFollowing ? (
                      <>
                        <UserMinus className="w-4 h-4 mr-2" />
                        Unfollow
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Follow
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={() => navigate(`/messages/${id}`)}
                    variant="outline"
                    className="border-blue-300 text-blue-600 hover:bg-blue-50"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Message
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Tabs defaultValue="about" className="space-y-6">
          <TabsList className="bg-white border border-blue-100">
            <TabsTrigger value="about" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <User className="w-4 h-4 mr-2" />
              About
            </TabsTrigger>
            <TabsTrigger value="qualifications" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <GraduationCap className="w-4 h-4 mr-2" />
              Qualifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="about">
            <div className="space-y-6">
              {/* Biography */}
              <Card className="bg-white border-blue-100">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-blue-600 flex items-center">
                      <User className="w-5 h-5 mr-2" />
                      Biography
                    </CardTitle>
                    {isOwnProfile && !isEditing && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsEditing(true)}
                        className="border-blue-300 text-blue-600"
                      >
                        Edit Profile
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {isEditing ? (
                    <Textarea
                      value={editBiography}
                      onChange={(e) => setEditBiography(e.target.value)}
                      placeholder="Tell us about yourself..."
                      className="min-h-[100px]"
                    />
                  ) : (
                    <p className="text-gray-700 whitespace-pre-wrap">
                      {profile.biography || 'No biography yet'}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Employment */}
              <Card className="bg-white border-blue-100">
                <CardHeader>
                  <CardTitle className="text-blue-600 flex items-center">
                    <Briefcase className="w-5 h-5 mr-2" />
                    Current Employment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isEditing ? (
                    <Input
                      value={editEmployment}
                      onChange={(e) => setEditEmployment(e.target.value)}
                      placeholder="Software Engineer at TechCorp"
                    />
                  ) : (
                    <p className="text-gray-700">
                      {profile.currentEmployment || 'Not specified'}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Research Area */}
              <Card className="bg-white border-blue-100">
                <CardHeader>
                  <CardTitle className="text-blue-600 flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    Research Area
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isEditing ? (
                    <Input
                      value={editResearch}
                      onChange={(e) => setEditResearch(e.target.value)}
                      placeholder="Artificial Intelligence, Machine Learning"
                    />
                  ) : (
                    <p className="text-gray-700">
                      {profile.researchArea || 'Not specified'}
                    </p>
                  )}
                </CardContent>
              </Card>

              {isEditing && (
                <div className="flex justify-end space-x-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsEditing(false);
                      setEditBiography(profile.biography || '');
                      setEditEmployment(profile.currentEmployment || '');
                      setEditResearch(profile.researchArea || '');
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleUpdateProfile}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Save Changes
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="qualifications">
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-blue-600 flex items-center">
                    <GraduationCap className="w-5 h-5 mr-2" />
                    Qualifications & Certificates
                  </CardTitle>
                  {isOwnProfile && (
                    <Dialog open={showDocumentDialog} onOpenChange={setShowDocumentDialog}>
                      <DialogTrigger asChild>
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Document
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-white">
                        <DialogHeader>
                          <DialogTitle className="text-blue-600">Upload Qualification</DialogTitle>
                          <DialogDescription className="text-gray-500">
                            Upload your qualification or certificate to get verified.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label>Document Type</Label>
                            <select
                              value={documentType}
                              onChange={(e) => setDocumentType(e.target.value)}
                              className="w-full border border-gray-300 rounded-md px-3 py-2"
                            >
                              <option value="qualification">Qualification</option>
                              <option value="certificate">Certificate</option>
                              <option value="license">License</option>
                            </select>
                          </div>
                          <div>
                            <Label>Select File</Label>
                            <Input
                              type="file"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}
                            />
                            <p className="text-sm text-gray-500 mt-2">
                              Accepted formats: PDF, JPG, PNG
                            </p>
                          </div>
                          <div className="flex justify-end space-x-3">
                            <Button
                              variant="outline"
                              onClick={() => {
                                setShowDocumentDialog(false);
                                setDocumentFile(null);
                              }}
                            >
                              Cancel
                            </Button>
                            <Button
                              onClick={handleDocumentUpload}
                              disabled={isUploading || !documentFile}
                              className="bg-blue-600 hover:bg-blue-700 text-white"
                            >
                              {isUploading ? 'Uploading...' : 'Upload'}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {profile.qualifications && profile.qualifications.length > 0 ? (
                  <div className="space-y-3">
                    {profile.qualifications.map((qual: any, index: number) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 bg-blue-50 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <GraduationCap className="w-5 h-5 text-blue-600" />
                          <div>
                            <p className="font-medium text-gray-900">{qual.fileName}</p>
                            <p className="text-sm text-gray-600">
                              Verified on {new Date(qual.verifiedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <GraduationCap className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500">
                      {isOwnProfile 
                        ? 'No verified qualifications yet. Upload your documents to get verified!'
                        : 'No verified qualifications'
                      }
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}