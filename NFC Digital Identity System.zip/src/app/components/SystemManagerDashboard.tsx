import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Users, 
  Calendar, 
  FileText, 
  CheckCircle, 
  XCircle,
  Eye,
  Shield
} from 'lucide-react';
import { toast } from 'sonner';

export default function SystemManagerDashboard() {
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [allEvents, setAllEvents] = useState<any[]>([]);
  const [pendingDocuments, setPendingDocuments] = useState<any[]>([]);
  const [documentUrls, setDocumentUrls] = useState<Record<string, string>>({});
  const [userProfiles, setUserProfiles] = useState<Record<string, any>>({});

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (user && accessToken) {
      if (user.role !== 'system_manager') {
        navigate('/');
        return;
      }
      fetchAllUsers();
      fetchAllEvents();
      fetchPendingDocuments();
    }
  }, [user, accessToken]);

  const fetchAllUsers = async () => {
    try {
      const response = await fetch(`${baseUrl}/users`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setAllUsers(data.users || []);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const fetchAllEvents = async () => {
    try {
      const response = await fetch(`${baseUrl}/events`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setAllEvents(data.events || []);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const fetchPendingDocuments = async () => {
    try {
      const response = await fetch(`${baseUrl}/documents/pending`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setPendingDocuments(data.documents || []);

      // Fetch user profiles for document owners
      for (const doc of data.documents || []) {
        if (!userProfiles[doc.userId]) {
          fetchUserProfile(doc.userId);
        }
      }
    } catch (error) {
      console.error('Error fetching documents:', error);
    }
  };

  const fetchUserProfile = async (userId: string) => {
    try {
      const response = await fetch(`${baseUrl}/users/${userId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setUserProfiles(prev => ({ ...prev, [userId]: data.user }));
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const fetchDocumentUrl = async (documentId: string) => {
    try {
      const response = await fetch(`${baseUrl}/documents/${documentId}/file`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setDocumentUrls(prev => ({ ...prev, [documentId]: data.url }));
      // Open in new tab
      window.open(data.url, '_blank');
    } catch (error) {
      console.error('Error fetching document URL:', error);
      toast.error('Failed to load document');
    }
  };

  const handleVerifyDocument = async (documentId: string, verified: boolean) => {
    try {
      const response = await fetch(`${baseUrl}/documents/${documentId}/verify`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ verified }),
      });

      if (response.ok) {
        toast.success(verified ? 'Document verified!' : 'Document rejected');
        fetchPendingDocuments();
      } else {
        toast.error('Failed to verify document');
      }
    } catch (error) {
      console.error('Error verifying document:', error);
      toast.error('Failed to verify document');
    }
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '??';
  };

  if (!user || user.role !== 'system_manager') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md w-full bg-white border-blue-100">
          <CardContent className="pt-6 text-center">
            <p className="text-gray-700">Access denied. System Manager only.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Shield className="w-10 h-10 text-blue-600 mr-3" />
          <div>
            <h1 className="text-4xl font-bold text-gray-900">System Manager</h1>
            <p className="text-gray-600">Manage users, events, and verifications</p>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Users</p>
                  <p className="text-3xl font-bold text-blue-600">{allUsers.length}</p>
                </div>
                <Users className="w-12 h-12 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Events</p>
                  <p className="text-3xl font-bold text-blue-600">{allEvents.length}</p>
                </div>
                <Calendar className="w-12 h-12 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Pending Documents</p>
                  <p className="text-3xl font-bold text-orange-600">{pendingDocuments.length}</p>
                </div>
                <FileText className="w-12 h-12 text-orange-600 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="documents" className="space-y-6">
          <TabsList className="bg-white border border-blue-100">
            <TabsTrigger value="documents" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              Document Verification
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              All Users
            </TabsTrigger>
            <TabsTrigger value="events" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Calendar className="w-4 h-4 mr-2" />
              All Events
            </TabsTrigger>
          </TabsList>

          <TabsContent value="documents">
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <CardTitle className="text-blue-600">Pending Document Verifications</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingDocuments.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500">No pending documents</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingDocuments.map((doc) => {
                      const owner = userProfiles[doc.userId];
                      
                      return (
                        <div key={doc.id} className="border border-blue-100 rounded-lg p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-3">
                              <Avatar 
                                className="cursor-pointer"
                                onClick={() => navigate(`/profile/${doc.userId}`)}
                              >
                                <AvatarFallback className="bg-blue-600 text-white">
                                  {owner ? getInitials(owner.fullName) : '??'}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-semibold text-gray-900">
                                  {owner?.fullName || 'Loading...'}
                                </p>
                                <p className="text-sm text-gray-600">{doc.fileName}</p>
                                <p className="text-xs text-gray-500">
                                  Type: {doc.documentType} • Uploaded: {new Date(doc.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => fetchDocumentUrl(doc.id)}
                                className="border-blue-300 text-blue-600"
                              >
                                <Eye className="w-4 h-4 mr-1" />
                                View
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => handleVerifyDocument(doc.id, true)}
                                className="bg-green-600 hover:bg-green-700 text-white"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Verify
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => handleVerifyDocument(doc.id, false)}
                                className="bg-red-600 hover:bg-red-700 text-white"
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Reject
                              </Button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <CardTitle className="text-blue-600">All Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {allUsers.map((u) => (
                    <div
                      key={u.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50 transition"
                      onClick={() => navigate(`/profile/${u.id}`)}
                    >
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarFallback className="bg-blue-600 text-white">
                            {getInitials(u.fullName)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold text-gray-900">{u.fullName}</p>
                          <p className="text-sm text-gray-600">{u.email}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-blue-600 capitalize">{u.role.replace('_', ' ')}</p>
                        <p className="text-xs text-gray-500">
                          {u.followers?.length || 0} followers
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="events">
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <CardTitle className="text-blue-600">All Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allEvents.map((event) => (
                    <div
                      key={event.id}
                      className="border border-blue-100 rounded-lg p-4 cursor-pointer hover:shadow-md transition"
                      onClick={() => navigate(`/events/${event.id}`)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{event.name}</h3>
                          <p className="text-sm text-gray-600">{event.location}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(event.date).toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600">
                            {event.registeredUsers?.length || 0} / {event.capacity}
                          </p>
                          <p className="text-xs text-gray-500">registered</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
