import { useState, useEffect } from 'react';
import { useParams } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { ScrollArea } from './ui/scroll-area';
import { MessageCircle, Send } from 'lucide-react';
import { toast } from 'sonner';

export default function Messages() {
  const { userId } = useParams();
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [conversations, setConversations] = useState<any[]>([]);
  const [currentMessages, setCurrentMessages] = useState<any[]>([]);
  const [selectedUserId, setSelectedUserId] = useState(userId || '');
  const [newMessage, setNewMessage] = useState('');
  const [userProfiles, setUserProfiles] = useState<Record<string, any>>({});
  const [isSending, setIsSending] = useState(false);

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (user && accessToken) {
      fetchConversations();
    }
  }, [user, accessToken]);

  useEffect(() => {
    if (selectedUserId) {
      fetchMessages(selectedUserId);
    }
  }, [selectedUserId]);

  useEffect(() => {
    if (userId) {
      setSelectedUserId(userId);
    }
  }, [userId]);

  const fetchConversations = async () => {
    try {
      const response = await fetch(`${baseUrl}/conversations`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setConversations(data.conversations || []);

      // Fetch user profiles
      for (const conv of data.conversations || []) {
        if (!userProfiles[conv.userId]) {
          fetchUserProfile(conv.userId);
        }
      }
    } catch (error) {
      console.error('Error fetching conversations:', error);
    }
  };

  const fetchMessages = async (otherUserId: string) => {
    try {
      const response = await fetch(`${baseUrl}/messages/${otherUserId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setCurrentMessages(data.messages || []);

      if (!userProfiles[otherUserId]) {
        fetchUserProfile(otherUserId);
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const fetchUserProfile = async (userId: string) => {
    try {
      const response = await fetch(`${baseUrl}/users/${userId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setUserProfiles(prev => ({ ...prev, [userId]: data.user }));
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedUserId) return;

    setIsSending(true);
    try {
      const response = await fetch(`${baseUrl}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          recipientId: selectedUserId,
          content: newMessage,
        }),
      });

      if (response.ok) {
        setNewMessage('');
        fetchMessages(selectedUserId);
        fetchConversations();
      } else {
        toast.error('Failed to send message');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    } finally {
      setIsSending(false);
    }
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '??';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md w-full bg-white border-blue-100">
          <CardContent className="pt-6 text-center">
            <p className="text-gray-700">Please sign in to view messages</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">Messages</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Conversations List */}
          <Card className="bg-white border-blue-100 lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-blue-600">Conversations</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-300px)]">
                {conversations.length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    <MessageCircle className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p>No conversations yet</p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {conversations.map((conv) => {
                      const otherUser = userProfiles[conv.userId];
                      const isSelected = selectedUserId === conv.userId;
                      
                      return (
                        <div
                          key={conv.userId}
                          className={`p-4 cursor-pointer hover:bg-blue-50 transition ${
                            isSelected ? 'bg-blue-100' : ''
                          }`}
                          onClick={() => setSelectedUserId(conv.userId)}
                        >
                          <div className="flex items-center space-x-3">
                            <Avatar>
                              <AvatarFallback className="bg-blue-600 text-white">
                                {otherUser ? getInitials(otherUser.fullName) : '??'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-gray-900 truncate">
                                {otherUser?.fullName || 'Loading...'}
                              </p>
                              <p className="text-sm text-gray-500 truncate">
                                {conv.lastMessage?.content || 'No messages'}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Messages */}
          <Card className="bg-white border-blue-100 lg:col-span-2">
            {selectedUserId ? (
              <>
                <CardHeader className="border-b border-blue-100">
                  <div className="flex items-center space-x-3">
                    <Avatar 
                      className="cursor-pointer"
                      onClick={() => navigate(`/profile/${selectedUserId}`)}
                    >
                      <AvatarFallback className="bg-blue-600 text-white">
                        {userProfiles[selectedUserId] 
                          ? getInitials(userProfiles[selectedUserId].fullName) 
                          : '??'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle 
                        className="text-blue-600 cursor-pointer hover:text-blue-700"
                        onClick={() => navigate(`/profile/${selectedUserId}`)}
                      >
                        {userProfiles[selectedUserId]?.fullName || 'Loading...'}
                      </CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[calc(100vh-450px)] p-6">
                    <div className="space-y-4">
                      {currentMessages.map((message) => {
                        const isOwn = message.senderId === user.id;
                        
                        return (
                          <div
                            key={message.id}
                            className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                          >
                            <div
                              className={`max-w-[70%] rounded-lg px-4 py-2 ${
                                isOwn
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-gray-100 text-gray-900'
                              }`}
                            >
                              <p className="whitespace-pre-wrap">{message.content}</p>
                              <p
                                className={`text-xs mt-1 ${
                                  isOwn ? 'text-blue-100' : 'text-gray-500'
                                }`}
                              >
                                {new Date(message.createdAt).toLocaleTimeString()}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                      
                      {currentMessages.length === 0 && (
                        <div className="text-center text-gray-500 py-12">
                          <MessageCircle className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                          <p>No messages yet. Start the conversation!</p>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                  
                  {/* Message Input */}
                  <div className="border-t border-blue-100 p-4">
                    <form onSubmit={handleSendMessage} className="flex space-x-3">
                      <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 border-blue-100 focus:border-blue-300"
                      />
                      <Button
                        type="submit"
                        disabled={isSending || !newMessage.trim()}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Send className="w-5 h-5" />
                      </Button>
                    </form>
                  </div>
                </CardContent>
              </>
            ) : (
              <CardContent className="h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MessageCircle className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                  <p>Select a conversation to start messaging</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
