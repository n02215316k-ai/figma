import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId } from '/utils/supabase/info';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Users, Calendar, TrendingUp, CheckCircle, XCircle } from 'lucide-react';

export default function AdminDashboard() {
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [myEvents, setMyEvents] = useState<any[]>([]);
  const [eventStats, setEventStats] = useState<Record<string, any>>({});

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (user && accessToken) {
      if (user.role !== 'admin' && user.role !== 'system_manager') {
        navigate('/');
        return;
      }
      fetchMyEvents();
    }
  }, [user, accessToken]);

  const fetchMyEvents = async () => {
    try {
      const response = await fetch(`${baseUrl}/events`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      const adminEvents = data.events?.filter((e: any) => e.creatorId === user?.id) || [];
      setMyEvents(adminEvents);

      // Fetch stats for each event
      for (const event of adminEvents) {
        fetchEventStats(event.id);
      }
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const fetchEventStats = async (eventId: string) => {
    try {
      const response = await fetch(`${baseUrl}/events/${eventId}/stats`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setEventStats(prev => ({ ...prev, [eventId]: data.stats }));
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  if (!user || (user.role !== 'admin' && user.role !== 'system_manager')) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md w-full bg-white border-blue-100">
          <CardContent className="pt-6 text-center">
            <p className="text-gray-700">Access denied. Admin only.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalRegistrations = myEvents.reduce((sum, e) => sum + (e.registeredUsers?.length || 0), 0);
  const totalAttendance = myEvents.reduce((sum, e) => sum + (e.totalCheckIns || 0), 0);
  const currentAttendees = myEvents.reduce((sum, e) => sum + (e.currentAttendees || 0), 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Event Analytics</h1>
        <p className="text-gray-600 mb-8">Track your events performance</p>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Events</p>
                  <p className="text-3xl font-bold text-blue-600">{myEvents.length}</p>
                </div>
                <Calendar className="w-12 h-12 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Registrations</p>
                  <p className="text-3xl font-bold text-blue-600">{totalRegistrations}</p>
                </div>
                <Users className="w-12 h-12 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Current Attendees</p>
                  <p className="text-3xl font-bold text-green-600">{currentAttendees}</p>
                </div>
                <CheckCircle className="w-12 h-12 text-green-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Check-ins</p>
                  <p className="text-3xl font-bold text-blue-600">{totalAttendance}</p>
                </div>
                <TrendingUp className="w-12 h-12 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Events Breakdown */}
        <Card className="bg-white border-blue-100">
          <CardHeader>
            <CardTitle className="text-blue-600">Event Details</CardTitle>
          </CardHeader>
          <CardContent>
            {myEvents.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">No events created yet</p>
              </div>
            ) : (
              <div className="space-y-6">
                {myEvents.map((event) => {
                  const stats = eventStats[event.id];
                  
                  return (
                    <div 
                      key={event.id} 
                      className="border border-blue-100 rounded-lg p-6 cursor-pointer hover:shadow-md transition"
                      onClick={() => navigate(`/events/${event.id}`)}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900">{event.name}</h3>
                          <p className="text-gray-600">{new Date(event.date).toLocaleString()}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600">Capacity</p>
                          <p className="text-xl font-bold text-blue-600">
                            {event.registeredUsers?.length || 0} / {event.capacity}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="bg-blue-50 rounded p-3">
                          <p className="text-sm text-gray-600 mb-1">Registered</p>
                          <p className="text-2xl font-bold text-blue-600">
                            {event.registeredUsers?.length || 0}
                          </p>
                        </div>
                        <div className="bg-green-50 rounded p-3">
                          <p className="text-sm text-gray-600 mb-1">Currently In</p>
                          <p className="text-2xl font-bold text-green-600">
                            {event.currentAttendees || 0}
                          </p>
                        </div>
                        <div className="bg-purple-50 rounded p-3">
                          <p className="text-sm text-gray-600 mb-1">Total Check-ins</p>
                          <p className="text-2xl font-bold text-purple-600">
                            {event.totalCheckIns || 0}
                          </p>
                        </div>
                      </div>

                      {stats && stats.attendanceRecords && stats.attendanceRecords.length > 0 && (
                        <div className="mt-4">
                          <p className="text-sm font-semibold text-gray-700 mb-2">Recent Activity:</p>
                          <div className="space-y-1 max-h-40 overflow-y-auto">
                            {stats.attendanceRecords.slice(0, 5).map((record: any, idx: number) => {
                              const lastCheckIn = record.checkIns[record.checkIns.length - 1];
                              return (
                                <div key={idx} className="text-sm text-gray-600 flex items-center">
                                  {record.status === 'checked_in' ? (
                                    <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                                  ) : (
                                    <XCircle className="w-4 h-4 mr-2 text-orange-600" />
                                  )}
                                  <span>{record.status === 'checked_in' ? 'Checked in' : 'Checked out'} by {lastCheckIn?.scannerName}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
