import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { projectId } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { ArrowLeft, Users, Calendar } from 'lucide-react';
import { toast } from 'sonner';

export default function ForumDetails() {
  const { id } = useParams();
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [forum, setForum] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [userProfiles, setUserProfiles] = useState<Record<string, any>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (id) {
      fetchForumDetails();
      fetchPosts();
    }
  }, [id]);

  const fetchForumDetails = async () => {
    try {
      const response = await fetch(`${baseUrl}/forums/${id}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setForum(data.forum);
    } catch (error) {
      console.error('Error fetching forum:', error);
    }
  };

  const fetchPosts = async () => {
    try {
      const response = await fetch(`${baseUrl}/forums/${id}/posts`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setPosts(data.posts || []);

      // Fetch user profiles
      if (data.posts && Array.isArray(data.posts)) {
        const authorIds = [...new Set(data.posts.map((p: any) => p.authorId))];
        for (const authorId of authorIds) {
          if (!userProfiles[authorId]) {
            fetchUserProfile(authorId);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
      setPosts([]);
    }
  };

  const fetchUserProfile = async (userId: string) => {
    try {
      const response = await fetch(`${baseUrl}/users/${userId}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` },
      });
      const data = await response.json();
      setUserProfiles(prev => ({ ...prev, [userId]: data.user }));
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(`${baseUrl}/forums/${id}/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ content: newPostContent }),
      });

      if (response.ok) {
        setNewPostContent('');
        toast.success('Posted!');
        fetchPosts();
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to post');
      }
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to post');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleJoinForum = async () => {
    try {
      const response = await fetch(`${baseUrl}/forums/${id}/join`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        toast.success('Joined forum!');
        fetchForumDetails();
      }
    } catch (error) {
      console.error('Error joining forum:', error);
      toast.error('Failed to join forum');
    }
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '??';
  };

  if (!forum) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-blue-600 text-xl">Loading...</div>
      </div>
    );
  }

  const isMember = user && forum.members?.includes(user.id);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate('/forums')}
          className="mb-6 text-gray-700 hover:text-blue-600"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Forums
        </Button>

        {/* Forum Header */}
        <Card className="bg-white border-blue-100 mb-6">
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-blue-600 mb-4">{forum.name}</h1>
                <p className="text-gray-700 mb-4">{forum.description}</p>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-2 text-blue-600" />
                    {forum.members?.length || 0} members
                  </div>
                  {forum.eventId && (
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2 text-blue-600" />
                      Event Forum
                    </div>
                  )}
                </div>
              </div>
              
              {user && !isMember && (
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 text-white mt-4 md:mt-0"
                  onClick={handleJoinForum}
                >
                  Join Forum
                </Button>
              )}
            </div>
          </CardHeader>
        </Card>

        {/* Create Post */}
        {user && isMember && (
          <Card className="bg-white border-blue-100 mb-6">
            <CardContent className="pt-6">
              <form onSubmit={handleCreatePost}>
                <Textarea
                  placeholder="Share with the community..."
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  className="min-h-[100px] resize-none border-blue-100 focus:border-blue-300"
                />
                <div className="mt-4 flex justify-end">
                  <Button 
                    type="submit" 
                    disabled={isSubmitting || !newPostContent.trim()}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {isSubmitting ? 'Posting...' : 'Post'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {!isMember && user && (
          <Card className="bg-blue-50 border-blue-100 mb-6">
            <CardContent className="py-6 text-center">
              <p className="text-gray-700">Join this forum to participate in discussions</p>
            </CardContent>
          </Card>
        )}

        {/* Posts */}
        <div className="space-y-4">
          {posts.map((post) => {
            const author = userProfiles[post.authorId];
            
            return (
              <Card key={post.id} className="bg-white border-blue-100">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <Avatar 
                      className="cursor-pointer"
                      onClick={() => navigate(`/profile/${post.authorId}`)}
                    >
                      <AvatarFallback className="bg-blue-600 text-white">
                        {author ? getInitials(author.fullName) : '??'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p 
                        className="font-semibold text-gray-900 cursor-pointer hover:text-blue-600"
                        onClick={() => navigate(`/profile/${post.authorId}`)}
                      >
                        {author?.fullName || 'Loading...'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {new Date(post.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-800 whitespace-pre-wrap">{post.content}</p>
                </CardContent>
              </Card>
            );
          })}

          {posts.length === 0 && (
            <Card className="bg-white border-blue-100">
              <CardContent className="py-12 text-center">
                <p className="text-gray-500">No posts yet. Start the conversation!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}