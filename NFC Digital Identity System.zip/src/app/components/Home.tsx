import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Heart, MessageCircle, Share2, Calendar, Users } from 'lucide-react';
import { toast } from 'sonner';
import { QrCode, User } from 'lucide-react';

export default function Home() {
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [posts, setPosts] = useState<any[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [upcomingEvents, setUpcomingEvents] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userProfiles, setUserProfiles] = useState<Record<string, any>>({});

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (user && accessToken) {
      fetchPosts();
      fetchEvents();
    }
  }, [user, accessToken]);

  const fetchPosts = async () => {
    try {
      const response = await fetch(`${baseUrl}/posts`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setPosts(data.posts || []);
      
      // Fetch user profiles for all post authors
      if (data.posts && Array.isArray(data.posts)) {
        const authorIds = [...new Set(data.posts.map((p: any) => p.authorId))];
        for (const authorId of authorIds) {
          if (!userProfiles[authorId]) {
            fetchUserProfile(authorId);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
      setPosts([]);
    }
  };

  const fetchUserProfile = async (userId: string) => {
    try {
      const response = await fetch(`${baseUrl}/users/${userId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setUserProfiles(prev => ({ ...prev, [userId]: data.user }));
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const fetchEvents = async () => {
    try {
      const response = await fetch(`${baseUrl}/events`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const data = await response.json();
      setUpcomingEvents(data.events?.slice(0, 5) || []);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(`${baseUrl}/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ content: newPostContent }),
      });

      if (response.ok) {
        setNewPostContent('');
        toast.success('Post created!');
        fetchPosts();
      } else {
        toast.error('Failed to create post');
      }
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to create post');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLikePost = async (postId: string) => {
    try {
      const response = await fetch(`${baseUrl}/posts/${postId}/like`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        fetchPosts();
      }
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (!user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-blue-50 to-white flex items-center justify-center">
        <div className="text-center px-4">
          <h1 className="text-6xl font-bold text-blue-600 mb-4">EventConnect</h1>
          <p className="text-2xl text-gray-700 mb-8">Event Management & Social Network</p>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Connect with professionals, attend events, join communities, and build your network. 
            Use NFC/QR technology for seamless event check-ins and networking.
          </p>
          <div className="flex justify-center space-x-4 text-gray-600">
            <div className="flex items-center space-x-2">
              <Calendar className="w-6 h-6 text-blue-600" />
              <span>Events</span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="w-6 h-6 text-blue-600" />
              <span>Forums</span>
            </div>
            <div className="flex items-center space-x-2">
              <MessageCircle className="w-6 h-6 text-blue-600" />
              <span>Messaging</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Feed */}
          <div className="lg:col-span-2 space-y-6">
            {/* Create Post */}
            <Card className="bg-white border-blue-100">
              <CardContent className="pt-6">
                <form onSubmit={handleCreatePost}>
                  <div className="flex space-x-4">
                    <Avatar>
                      <AvatarFallback className="bg-blue-600 text-white">
                        {getInitials(user.fullName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Share your thoughts..."
                        value={newPostContent}
                        onChange={(e) => setNewPostContent(e.target.value)}
                        className="min-h-[100px] resize-none border-blue-100 focus:border-blue-300"
                      />
                      <div className="mt-4 flex justify-end">
                        <Button 
                          type="submit" 
                          disabled={isSubmitting || !newPostContent.trim()}
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          {isSubmitting ? 'Posting...' : 'Post'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Posts Feed */}
            <div className="space-y-4">
              {posts.map((post) => {
                const author = userProfiles[post.authorId];
                const isLiked = post.likes?.includes(user?.id);
                
                return (
                  <Card key={post.id} className="bg-white border-blue-100">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <Avatar 
                          className="cursor-pointer"
                          onClick={() => navigate(`/profile/${post.authorId}`)}
                        >
                          <AvatarFallback className="bg-blue-600 text-white">
                            {author ? getInitials(author.fullName) : '??'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p 
                            className="font-semibold text-gray-900 cursor-pointer hover:text-blue-600"
                            onClick={() => navigate(`/profile/${post.authorId}`)}
                          >
                            {author?.fullName || 'Loading...'}
                          </p>
                          <p className="text-sm text-gray-500">
                            {new Date(post.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-800 whitespace-pre-wrap">{post.content}</p>
                      
                      <div className="mt-4 flex items-center space-x-6 text-gray-600">
                        <button
                          onClick={() => handleLikePost(post.id)}
                          className={`flex items-center space-x-2 hover:text-blue-600 transition ${
                            isLiked ? 'text-blue-600' : ''
                          }`}
                        >
                          <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                          <span>{post.likes?.length || 0}</span>
                        </button>
                        <button className="flex items-center space-x-2 hover:text-blue-600 transition">
                          <MessageCircle className="w-5 h-5" />
                          <span>{post.comments?.length || 0}</span>
                        </button>
                        <button className="flex items-center space-x-2 hover:text-blue-600 transition">
                          <Share2 className="w-5 h-5" />
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {posts.length === 0 && (
                <Card className="bg-white border-blue-100">
                  <CardContent className="py-12 text-center">
                    <p className="text-gray-500">No posts yet. Be the first to share something!</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Events */}
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <h3 className="font-semibold text-gray-900 flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                  Upcoming Events
                </h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingEvents.map((event) => (
                    <div
                      key={event.id}
                      className="p-3 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition"
                      onClick={() => navigate(`/events/${event.id}`)}
                    >
                      <p className="font-medium text-gray-900">{event.name}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(event.date).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                  
                  {upcomingEvents.length === 0 && (
                    <p className="text-gray-500 text-sm">No upcoming events</p>
                  )}
                  
                  <Button 
                    variant="outline" 
                    className="w-full border-blue-300 text-blue-600 hover:bg-blue-50"
                    onClick={() => navigate('/events')}
                  >
                    View All Events
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <h3 className="font-semibold text-gray-900">Quick Actions</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full border-blue-300 text-blue-600 hover:bg-blue-50 justify-start"
                    onClick={() => navigate('/events')}
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Browse Events
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full border-blue-300 text-blue-600 hover:bg-blue-50 justify-start"
                    onClick={() => navigate('/forums')}
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Join Forums
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full border-blue-300 text-blue-600 hover:bg-blue-50 justify-start"
                    onClick={() => navigate('/scan')}
                  >
                    <QrCode className="w-4 h-4 mr-2" />
                    Scan QR/NFC
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Sample Profiles */}
            <Card className="bg-white border-blue-100">
              <CardHeader>
                <h3 className="font-semibold text-gray-900 flex items-center">
                  <User className="w-5 h-5 mr-2 text-blue-600" />
                  Suggested Profiles
                </h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div
                    className="p-3 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition"
                    onClick={() => navigate('/profile/user-1')}
                  >
                    <p className="font-medium text-gray-900">Thabo Ndlovu</p>
                    <p className="text-sm text-gray-600">AI & Machine Learning</p>
                  </div>
                  <div
                    className="p-3 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition"
                    onClick={() => navigate('/profile/user-2')}
                  >
                    <p className="font-medium text-gray-900">Nokuthula Moyo</p>
                    <p className="text-sm text-gray-600">Event Manager</p>
                  </div>
                  <div
                    className="p-3 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition"
                    onClick={() => navigate('/profile/user-3')}
                  >
                    <p className="font-medium text-gray-900">Tendai Chikwanda</p>
                    <p className="text-sm text-gray-600">Data Science</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}