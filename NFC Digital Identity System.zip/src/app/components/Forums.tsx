import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Users, Search, Plus, MessageSquare, Calendar } from 'lucide-react';
import { toast } from 'sonner';

export default function Forums() {
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [forums, setForums] = useState<any[]>([]);
  const [filteredForums, setFilteredForums] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  // Create forum form
  const [forumName, setForumName] = useState('');
  const [forumDescription, setForumDescription] = useState('');

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    fetchForums();
  }, []);

  useEffect(() => {
    if (searchQuery.trim()) {
      searchForums(searchQuery);
    } else {
      setFilteredForums(forums);
    }
  }, [searchQuery, forums]);

  const fetchForums = async () => {
    try {
      const response = await fetch(`${baseUrl}/forums`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setForums(data.forums || []);
      setFilteredForums(data.forums || []);
    } catch (error) {
      console.error('Error fetching forums:', error);
    }
  };

  const searchForums = async (query: string) => {
    try {
      const response = await fetch(`${baseUrl}/search/forums?q=${encodeURIComponent(query)}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setFilteredForums(data.forums || []);
    } catch (error) {
      console.error('Error searching forums:', error);
    }
  };

  const handleCreateForum = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);

    try {
      const response = await fetch(`${baseUrl}/forums`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          name: forumName,
          description: forumDescription,
        }),
      });

      if (response.ok) {
        toast.success('Forum created successfully!');
        setShowCreateDialog(false);
        resetForm();
        fetchForums();
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to create forum');
      }
    } catch (error) {
      console.error('Error creating forum:', error);
      toast.error('Failed to create forum');
    } finally {
      setIsCreating(false);
    }
  };

  const handleJoinForum = async (forumId: string) => {
    try {
      const response = await fetch(`${baseUrl}/forums/${forumId}/join`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        toast.success('Joined forum!');
        fetchForums();
      } else {
        toast.error('Failed to join forum');
      }
    } catch (error) {
      console.error('Error joining forum:', error);
      toast.error('Failed to join forum');
    }
  };

  const resetForm = () => {
    setForumName('');
    setForumDescription('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Forums</h1>
            <p className="text-gray-600">Join communities and discussions</p>
          </div>
          
          {user && (
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white mt-4 md:mt-0">
                  <Plus className="w-5 h-5 mr-2" />
                  Create Forum
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white">
                <DialogHeader>
                  <DialogTitle className="text-blue-600">Create New Forum</DialogTitle>
                  <DialogDescription className="text-gray-500">Create a community forum to connect with others.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateForum} className="space-y-4">
                  <div>
                    <Label htmlFor="forum-name">Forum Name</Label>
                    <Input
                      id="forum-name"
                      value={forumName}
                      onChange={(e) => setForumName(e.target.value)}
                      placeholder="AI Research Community"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="forum-description">Description</Label>
                    <Textarea
                      id="forum-description"
                      value={forumDescription}
                      onChange={(e) => setForumDescription(e.target.value)}
                      placeholder="A community for AI researchers..."
                      className="min-h-[100px]"
                      required
                    />
                  </div>
                  <div className="flex justify-end space-x-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowCreateDialog(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={isCreating}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {isCreating ? 'Creating...' : 'Create Forum'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search forums..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-blue-100 focus:border-blue-300"
            />
          </div>
        </div>

        {/* Forums Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredForums.map((forum) => {
            const isMember = user && forum.members?.includes(user.id);
            const isEventForum = forum.eventId;
            
            return (
              <Card 
                key={forum.id} 
                className="bg-white border-blue-100 hover:shadow-lg transition cursor-pointer"
                onClick={() => navigate(`/forums/${forum.id}`)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-blue-600 flex-1">{forum.name}</CardTitle>
                    {isEventForum && (
                      <Calendar className="w-5 h-5 text-blue-600 flex-shrink-0 ml-2" />
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4 line-clamp-3">{forum.description}</p>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2 text-blue-600" />
                      {forum.members?.length || 0} members
                    </div>
                    <div className="flex items-center">
                      <MessageSquare className="w-4 h-4 mr-2 text-blue-600" />
                      {isEventForum ? 'Event Forum' : 'Community Forum'}
                    </div>
                  </div>

                  {user && (
                    <div className="mt-4">
                      {isMember ? (
                        <Button 
                          className="w-full bg-green-600 hover:bg-green-700 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                          }}
                          disabled
                        >
                          Joined ✓
                        </Button>
                      ) : (
                        <Button 
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleJoinForum(forum.id);
                          }}
                        >
                          Join Forum
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredForums.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No forums found</h3>
            <p className="text-gray-500">
              {searchQuery ? 'Try a different search term' : 'Be the first to create a forum!'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}