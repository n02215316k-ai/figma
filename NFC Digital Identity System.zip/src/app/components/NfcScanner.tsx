import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { projectId } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { QRCodeSVG } from 'qrcode.react';
import { QrCode, Nfc, User, Calendar, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function NfcScanner() {
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [scanMode, setScanMode] = useState<'event' | 'user'>('event');
  const [selectedEvent, setSelectedEvent] = useState('');
  const [scannedUserId, setScannedUserId] = useState('');
  const [events, setEvents] = useState<any[]>([]);
  const [scanResult, setScanResult] = useState<any>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [myQrData, setMyQrData] = useState('');

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (user) {
      fetchEvents();
      setMyQrData(JSON.stringify({ type: 'user', userId: user.id }));
    }
  }, [user]);

  const fetchEvents = async () => {
    try {
      const response = await fetch(`${baseUrl}/events`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      const myEvents = data.events?.filter((e: any) => 
        e.creatorId === user?.id || user?.role === 'system_manager'
      ) || [];
      setEvents(myEvents);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const handleEventScan = async () => {
    if (!selectedEvent || !scannedUserId.trim()) {
      toast.error('Please select an event and enter a user ID');
      return;
    }

    setIsScanning(true);
    setScanResult(null);

    try {
      // Parse QR code data if it's JSON
      let userId = scannedUserId.trim();
      try {
        const parsed = JSON.parse(userId);
        if (parsed.type === 'user' && parsed.userId) {
          userId = parsed.userId;
        }
      } catch {
        // Not JSON, use as-is
      }

      const response = await fetch(`${baseUrl}/scan/event`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          eventId: selectedEvent,
          scannedUserId: userId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setScanResult(data);
        
        if (data.attendance.status === 'checked_in') {
          toast.success('User checked in successfully!');
        } else {
          toast.success('User checked out successfully!');
        }
        
        setScannedUserId('');
      } else {
        const error = await response.json();
        toast.error(error.error || 'Scan failed');
      }
    } catch (error) {
      console.error('Error scanning:', error);
      toast.error('Scan failed');
    } finally {
      setIsScanning(false);
    }
  };

  const handleUserScan = async () => {
    if (!scannedUserId.trim()) {
      toast.error('Please enter a user ID');
      return;
    }

    setIsScanning(true);
    setScanResult(null);

    try {
      // Parse QR code data if it's JSON
      let userId = scannedUserId.trim();
      try {
        const parsed = JSON.parse(userId);
        if (parsed.type === 'user' && parsed.userId) {
          userId = parsed.userId;
        }
      } catch {
        // Not JSON, use as-is
      }

      const response = await fetch(`${baseUrl}/scan/user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          scannedUserId: userId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        toast.success('Navigating to profile...');
        navigate(`/profile/${userId}`);
      } else {
        const error = await response.json();
        toast.error(error.error || 'User not found');
      }
    } catch (error) {
      console.error('Error scanning:', error);
      toast.error('Scan failed');
    } finally {
      setIsScanning(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md w-full bg-white border-blue-100">
          <CardContent className="pt-6 text-center">
            <p className="text-gray-700">Please sign in to use the scanner</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">NFC / QR Scanner</h1>
        <p className="text-gray-600 mb-8">Scan badges for event check-in or networking</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Scanner */}
          <Card className="bg-white border-blue-100">
            <CardHeader>
              <CardTitle className="text-blue-600 flex items-center">
                <QrCode className="w-6 h-6 mr-2" />
                Scan Badge
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Tabs value={scanMode} onValueChange={(v) => setScanMode(v as any)}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="event">
                    <Calendar className="w-4 h-4 mr-2" />
                    Event Check-in
                  </TabsTrigger>
                  <TabsTrigger value="user">
                    <User className="w-4 h-4 mr-2" />
                    Networking
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="event" className="space-y-4">
                  <div>
                    <Label>Select Event</Label>
                    <Select value={selectedEvent} onValueChange={setSelectedEvent}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose an event..." />
                      </SelectTrigger>
                      <SelectContent>
                        {events.map((event) => (
                          <SelectItem key={event.id} value={event.id}>
                            {event.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {events.length === 0 && (
                      <p className="text-sm text-gray-500 mt-2">
                        Only event admins can scan for check-in
                      </p>
                    )}
                  </div>

                  <div>
                    <Label>User ID or QR Code Data</Label>
                    <Input
                      value={scannedUserId}
                      onChange={(e) => setScannedUserId(e.target.value)}
                      placeholder="Paste user ID or scan NFC..."
                    />
                    <p className="text-sm text-gray-500 mt-2">
                      Simulated NFC scan: paste the user ID from their QR code
                    </p>
                  </div>

                  <Button
                    onClick={handleEventScan}
                    disabled={isScanning || !selectedEvent || !scannedUserId.trim()}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {isScanning ? 'Scanning...' : 'Scan for Check-in'}
                  </Button>
                </TabsContent>

                <TabsContent value="user" className="space-y-4">
                  <div>
                    <Label>User ID or QR Code Data</Label>
                    <Input
                      value={scannedUserId}
                      onChange={(e) => setScannedUserId(e.target.value)}
                      placeholder="Paste user ID or scan NFC..."
                    />
                    <p className="text-sm text-gray-500 mt-2">
                      Scan another user's badge to view their profile
                    </p>
                  </div>

                  <Button
                    onClick={handleUserScan}
                    disabled={isScanning || !scannedUserId.trim()}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {isScanning ? 'Scanning...' : 'Scan for Networking'}
                  </Button>
                </TabsContent>
              </Tabs>

              {/* Scan Result */}
              {scanResult && scanMode === 'event' && (
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      {scanResult.attendance.status === 'checked_in' ? (
                        <>
                          <CheckCircle className="w-16 h-16 mx-auto text-green-600 mb-4" />
                          <h3 className="text-xl font-bold text-gray-900 mb-2">Checked In!</h3>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-16 h-16 mx-auto text-orange-600 mb-4" />
                          <h3 className="text-xl font-bold text-gray-900 mb-2">Checked Out</h3>
                        </>
                      )}
                      <p className="text-gray-700">
                        Current Attendees: {scanResult.currentAttendees}
                      </p>
                      <p className="text-sm text-gray-600 mt-2">
                        Scanner: {scanResult.attendance.checkIns[scanResult.attendance.checkIns.length - 1]?.scannerName}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* My QR Code */}
          <Card className="bg-white border-blue-100">
            <CardHeader>
              <CardTitle className="text-blue-600 flex items-center">
                <Nfc className="w-6 h-6 mr-2" />
                My Badge
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="bg-white p-6 rounded-lg inline-block border-2 border-blue-200">
                  <QRCodeSVG
                    value={myQrData}
                    size={200}
                    level="H"
                    includeMargin={true}
                  />
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Let others scan this to view your profile
                </p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm font-medium text-gray-900 mb-2">Your User ID:</p>
                <code className="text-xs bg-white px-3 py-2 rounded border border-blue-200 block break-all">
                  {user.id}
                </code>
              </div>

              <div className="text-sm text-gray-600 space-y-2">
                <p><strong>For Event Check-in:</strong></p>
                <p>Present this QR code to event staff at the entrance</p>
                <p className="mt-4"><strong>For Networking:</strong></p>
                <p>Share this with other attendees to connect</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card className="bg-white border-blue-100 mt-6">
          <CardHeader>
            <CardTitle className="text-blue-600">How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                  Event Check-in
                </h4>
                <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
                  <li>Event admins can scan attendee badges</li>
                  <li>First scan checks the user in</li>
                  <li>Second scan checks them out</li>
                  <li>Third scan checks them back in</li>
                  <li>Auto-joins event forum on check-in</li>
                  <li>Tracks attendance analytics</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                  <User className="w-5 h-5 mr-2 text-blue-600" />
                  Networking
                </h4>
                <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
                  <li>Any user can scan another user's badge</li>
                  <li>Instantly view their profile</li>
                  <li>See qualifications and research</li>
                  <li>Follow them or send a message</li>
                  <li>Build your professional network</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
