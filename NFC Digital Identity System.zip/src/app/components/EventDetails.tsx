import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar, MapPin, Users, MessageSquare, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export default function EventDetails() {
  const { id } = useParams();
  const { user, accessToken } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState<any>(null);
  const [forum, setForum] = useState<any>(null);
  const [forumPosts, setForumPosts] = useState<any[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [userProfiles, setUserProfiles] = useState<Record<string, any>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-0bb28fd0`;

  useEffect(() => {
    if (id) {
      fetchEventDetails();
    }
  }, [id]);

  const fetchEventDetails = async () => {
    try {
      const response = await fetch(`${baseUrl}/events/${id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const data = await response.json();
      setEvent(data.event);
      
      if (data.event?.forumId) {
        fetchForum(data.event.forumId);
      }
    } catch (error) {
      console.error('Error fetching event details:', error);
    }
  };

  const fetchForum = async (forumId: string) => {
    try {
      const [forumRes, postsRes] = await Promise.all([
        fetch(`${baseUrl}/forums/${forumId}`, {
          headers: { 'Authorization': `Bearer ${accessToken}` },
        }),
        fetch(`${baseUrl}/forums/${forumId}/posts`, {
          headers: { 'Authorization': `Bearer ${accessToken}` },
        }),
      ]);

      const forumData = await forumRes.json();
      const postsData = await postsRes.json();

      setForum(forumData.forum);
      setForumPosts(postsData.posts || []);

      // Fetch user profiles for post authors
      const authorIds = [...new Set(postsData.posts?.map((p: any) => p.authorId) || [])];
      for (const authorId of authorIds) {
        if (!userProfiles[authorId]) {
          fetchUserProfile(authorId);
        }
      }
    } catch (error) {
      console.error('Error fetching forum:', error);
    }
  };

  const fetchUserProfile = async (userId: string) => {
    try {
      const response = await fetch(`${baseUrl}/users/${userId}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` },
      });
      const data = await response.json();
      setUserProfiles(prev => ({ ...prev, [userId]: data.user }));
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const handleRegister = async () => {
    try {
      const response = await fetch(`${baseUrl}/events/${id}/register`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        toast.success('Registered successfully!');
        fetchEventDetails();
      } else {
        toast.error('Failed to register');
      }
    } catch (error) {
      console.error('Error registering:', error);
      toast.error('Failed to register');
    }
  };

  const handleForumPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim() || !forum) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(`${baseUrl}/forums/${forum.id}/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ content: newPostContent }),
      });

      if (response.ok) {
        setNewPostContent('');
        toast.success('Posted!');
        if (event?.forumId) {
          fetchForum(event.forumId);
        }
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to post');
      }
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to post');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '??';
  };

  if (!event) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-blue-600 text-xl">Loading...</div>
      </div>
    );
  }

  const isRegistered = user && event.registeredUsers?.includes(user.id);
  const isFull = event.registeredUsers?.length >= event.capacity;
  const isCreator = user && event.creatorId === user.id;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate('/events')}
          className="mb-6 text-gray-700 hover:text-blue-600"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Events
        </Button>

        {/* Event Header */}
        <Card className="bg-white border-blue-100 mb-6">
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div className="flex-1">
                <CardTitle className="text-3xl text-blue-600 mb-4">{event.name}</CardTitle>
                <div className="space-y-2 text-gray-600">
                  <div className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                    {new Date(event.date).toLocaleString()}
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-blue-600" />
                    {event.location}
                  </div>
                  <div className="flex items-center">
                    <Users className="w-5 h-5 mr-2 text-blue-600" />
                    {event.registeredUsers?.length || 0} / {event.capacity} registered
                  </div>
                </div>
              </div>
              
              {user && !isCreator && (
                <div className="mt-4 md:mt-0">
                  {isRegistered ? (
                    <Button 
                      className="bg-green-600 hover:bg-green-700 text-white"
                      disabled
                    >
                      Registered ✓
                    </Button>
                  ) : isFull ? (
                    <Button className="bg-gray-400 text-white" disabled>
                      Event Full
                    </Button>
                  ) : (
                    <Button 
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={handleRegister}
                    >
                      Register Now
                    </Button>
                  )}
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 whitespace-pre-wrap">{event.description}</p>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="forum" className="space-y-6">
          <TabsList className="bg-white border border-blue-100">
            <TabsTrigger value="forum" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <MessageSquare className="w-4 h-4 mr-2" />
              Forum
            </TabsTrigger>
            <TabsTrigger value="attendees" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              Attendees
            </TabsTrigger>
          </TabsList>

          <TabsContent value="forum" className="space-y-6">
            {user && isRegistered && forum && (
              <Card className="bg-white border-blue-100">
                <CardContent className="pt-6">
                  <form onSubmit={handleForumPost}>
                    <Textarea
                      placeholder="Share with the community..."
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                      className="min-h-[100px] resize-none border-blue-100 focus:border-blue-300"
                    />
                    <div className="mt-4 flex justify-end">
                      <Button 
                        type="submit" 
                        disabled={isSubmitting || !newPostContent.trim()}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        {isSubmitting ? 'Posting...' : 'Post'}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            {!isRegistered && user && (
              <Card className="bg-blue-50 border-blue-100">
                <CardContent className="py-6 text-center">
                  <p className="text-gray-700">Register for this event to join the forum discussion</p>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {forumPosts.map((post) => {
                const author = userProfiles[post.authorId];
                
                return (
                  <Card key={post.id} className="bg-white border-blue-100">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <Avatar 
                          className="cursor-pointer"
                          onClick={() => navigate(`/profile/${post.authorId}`)}
                        >
                          <AvatarFallback className="bg-blue-600 text-white">
                            {author ? getInitials(author.fullName) : '??'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p 
                            className="font-semibold text-gray-900 cursor-pointer hover:text-blue-600"
                            onClick={() => navigate(`/profile/${post.authorId}`)}
                          >
                            {author?.fullName || 'Loading...'}
                          </p>
                          <p className="text-sm text-gray-500">
                            {new Date(post.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-800 whitespace-pre-wrap">{post.content}</p>
                    </CardContent>
                  </Card>
                );
              })}

              {forumPosts.length === 0 && (
                <Card className="bg-white border-blue-100">
                  <CardContent className="py-12 text-center">
                    <MessageSquare className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500">No posts yet. Start the conversation!</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="attendees">
            <Card className="bg-white border-blue-100">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {event.registeredUsers?.map((userId: string) => {
                    const attendee = userProfiles[userId];
                    if (!attendee && !userProfiles[userId]) {
                      fetchUserProfile(userId);
                    }
                    
                    return (
                      <div
                        key={userId}
                        className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50 transition"
                        onClick={() => navigate(`/profile/${userId}`)}
                      >
                        <Avatar>
                          <AvatarFallback className="bg-blue-600 text-white">
                            {attendee ? getInitials(attendee.fullName) : '??'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-gray-900">
                            {attendee?.fullName || 'Loading...'}
                          </p>
                          <p className="text-sm text-gray-500">
                            {attendee?.currentEmployment || 'Professional'}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {(!event.registeredUsers || event.registeredUsers.length === 0) && (
                  <div className="text-center py-12">
                    <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500">No attendees yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
