import { createBrowserRouter } from "react-router";
import Root from "./components/Root";
import Home from "./components/Home";
import Events from "./components/Events";
import EventDetails from "./components/EventDetails";
import Forums from "./components/Forums";
import ForumDetails from "./components/ForumDetails";
import Profile from "./components/Profile";
import Messages from "./components/Messages";
import AdminDashboard from "./components/AdminDashboard";
import SystemManagerDashboard from "./components/SystemManagerDashboard";
import NfcScanner from "./components/NfcScanner";
import NotFound from "./components/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "events", Component: Events },
      { path: "events/:id", Component: EventDetails },
      { path: "forums", Component: Forums },
      { path: "forums/:id", Component: ForumDetails },
      { path: "profile", Component: Profile },
      { path: "profile/:id", Component: Profile },
      { path: "messages", Component: Messages },
      { path: "admin", Component: AdminDashboard },
      { path: "system-manager", Component: SystemManagerDashboard },
      { path: "scan", Component: NfcScanner },
      { path: "*", Component: NotFound },
    ],
  },
]);