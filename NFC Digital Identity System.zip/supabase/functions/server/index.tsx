import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

// Create Supabase clients
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_ANON_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize storage bucket for documents
async function initStorage() {
  const bucketName = 'make-0bb28fd0-documents';
  try {
    const { data: buckets } = await supabaseAdmin.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    if (!bucketExists) {
      await supabaseAdmin.storage.createBucket(bucketName, { public: false });
      console.log(`Created bucket: ${bucketName}`);
    }
  } catch (error) {
    console.error(`Error initializing storage: ${error}`);
  }
}
initStorage();

// Helper function to get authenticated user
async function getAuthUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return null;
  }
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
  if (error || !user) {
    return null;
  }
  return user;
}

// Helper to generate unique IDs
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Health check endpoint
app.get("/make-server-0bb28fd0/health", (c) => {
  return c.json({ status: "ok" });
});

// ==================== AUTH ROUTES ====================

// Sign up
app.post("/make-server-0bb28fd0/signup", async (c) => {
  try {
    const { email, password, fullName, role } = await c.req.json();
    
    if (!email || !password || !fullName || !role) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm since email server not configured
      user_metadata: { fullName, role }
    });

    if (authError) {
      console.error(`Auth error during signup: ${authError.message}`);
      return c.json({ error: authError.message }, 400);
    }

    // Create user profile in KV store
    const userId = authData.user.id;
    const userProfile = {
      id: userId,
      email,
      fullName,
      role, // 'user', 'admin', 'system_manager'
      biography: '',
      qualifications: [],
      currentEmployment: '',
      researchArea: '',
      followers: [],
      following: [],
      createdAt: new Date().toISOString(),
    };

    await kv.set(`user:${userId}`, userProfile);

    return c.json({ success: true, user: userProfile });
  } catch (error) {
    console.error(`Error during signup: ${error}`);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// Sign in
app.post("/make-server-0bb28fd0/signin", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const { data, error } = await supabaseClient.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error(`Auth error during signin: ${error.message}`);
      return c.json({ error: error.message }, 401);
    }

    // Get user profile
    const userProfile = await kv.get(`user:${data.user.id}`);

    return c.json({
      success: true,
      accessToken: data.session.access_token,
      user: userProfile,
    });
  } catch (error) {
    console.error(`Error during signin: ${error}`);
    return c.json({ error: 'Signin failed' }, 500);
  }
});

// Get session
app.get("/make-server-0bb28fd0/session", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const userProfile = await kv.get(`user:${user.id}`);
    return c.json({ user: userProfile });
  } catch (error) {
    console.error(`Error getting session: ${error}`);
    return c.json({ error: 'Session check failed' }, 500);
  }
});

// ==================== USER ROUTES ====================

// Get all users (system manager only)
app.get("/make-server-0bb28fd0/users", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const users = await kv.getByPrefix('user:');
    return c.json({ users });
  } catch (error) {
    console.error(`Error fetching users: ${error}`);
    return c.json({ error: 'Failed to fetch users' }, 500);
  }
});

// Get user profile
app.get("/make-server-0bb28fd0/users/:id", async (c) => {
  try {
    const userId = c.req.param('id');
    const userProfile = await kv.get(`user:${userId}`);
    
    if (!userProfile) {
      return c.json({ error: 'User not found' }, 404);
    }

    return c.json({ user: userProfile });
  } catch (error) {
    console.error(`Error fetching user profile: ${error}`);
    return c.json({ error: 'Failed to fetch user' }, 500);
  }
});

// Update user profile
app.put("/make-server-0bb28fd0/users/:id", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const userId = c.req.param('id');
    if (user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const updates = await c.req.json();
    const currentProfile = await kv.get(`user:${userId}`);
    
    const updatedProfile = {
      ...currentProfile,
      ...updates,
      id: userId, // Ensure ID doesn't change
    };

    await kv.set(`user:${userId}`, updatedProfile);
    return c.json({ success: true, user: updatedProfile });
  } catch (error) {
    console.error(`Error updating user profile: ${error}`);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Follow user
app.post("/make-server-0bb28fd0/users/:id/follow", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const targetUserId = c.req.param('id');
    const currentUserId = user.id;

    const currentUser = await kv.get(`user:${currentUserId}`);
    const targetUser = await kv.get(`user:${targetUserId}`);

    if (!targetUser) {
      return c.json({ error: 'User not found' }, 404);
    }

    // Add to following list
    if (!currentUser.following.includes(targetUserId)) {
      currentUser.following.push(targetUserId);
    }

    // Add to followers list
    if (!targetUser.followers.includes(currentUserId)) {
      targetUser.followers.push(currentUserId);
    }

    await kv.set(`user:${currentUserId}`, currentUser);
    await kv.set(`user:${targetUserId}`, targetUser);

    return c.json({ success: true });
  } catch (error) {
    console.error(`Error following user: ${error}`);
    return c.json({ error: 'Failed to follow user' }, 500);
  }
});

// Unfollow user
app.delete("/make-server-0bb28fd0/users/:id/follow", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const targetUserId = c.req.param('id');
    const currentUserId = user.id;

    const currentUser = await kv.get(`user:${currentUserId}`);
    const targetUser = await kv.get(`user:${targetUserId}`);

    if (!targetUser) {
      return c.json({ error: 'User not found' }, 404);
    }

    // Remove from following list
    currentUser.following = currentUser.following.filter((id: string) => id !== targetUserId);

    // Remove from followers list
    targetUser.followers = targetUser.followers.filter((id: string) => id !== currentUserId);

    await kv.set(`user:${currentUserId}`, currentUser);
    await kv.set(`user:${targetUserId}`, targetUser);

    return c.json({ success: true });
  } catch (error) {
    console.error(`Error unfollowing user: ${error}`);
    return c.json({ error: 'Failed to unfollow user' }, 500);
  }
});

// ==================== EVENT ROUTES ====================

// Get all events
app.get("/make-server-0bb28fd0/events", async (c) => {
  try {
    const events = await kv.getByPrefix('event:');
    return c.json({ events });
  } catch (error) {
    console.error(`Error fetching events: ${error}`);
    return c.json({ error: 'Failed to fetch events' }, 500);
  }
});

// Create event
app.post("/make-server-0bb28fd0/events", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const eventData = await c.req.json();
    const eventId = generateId();
    const forumId = generateId();

    const event = {
      id: eventId,
      ...eventData,
      creatorId: user.id,
      registeredUsers: [],
      currentAttendees: 0,
      totalCheckIns: 0,
      forumId,
      createdAt: new Date().toISOString(),
    };

    // Create event
    await kv.set(`event:${eventId}`, event);

    // Create associated forum
    const forum = {
      id: forumId,
      name: `${eventData.name} Forum`,
      description: `Discussion forum for ${eventData.name}`,
      creatorId: user.id,
      moderators: [user.id],
      members: [user.id],
      eventId,
      posts: [],
      createdAt: new Date().toISOString(),
    };

    await kv.set(`forum:${forumId}`, forum);

    return c.json({ success: true, event, forum });
  } catch (error) {
    console.error(`Error creating event: ${error}`);
    return c.json({ error: 'Failed to create event' }, 500);
  }
});

// Get event details
app.get("/make-server-0bb28fd0/events/:id", async (c) => {
  try {
    const eventId = c.req.param('id');
    const event = await kv.get(`event:${eventId}`);
    
    if (!event) {
      return c.json({ error: 'Event not found' }, 404);
    }

    return c.json({ event });
  } catch (error) {
    console.error(`Error fetching event: ${error}`);
    return c.json({ error: 'Failed to fetch event' }, 500);
  }
});

// Update event
app.put("/make-server-0bb28fd0/events/:id", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const eventId = c.req.param('id');
    const event = await kv.get(`event:${eventId}`);

    if (!event) {
      return c.json({ error: 'Event not found' }, 404);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (event.creatorId !== user.id && currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const updates = await c.req.json();
    const updatedEvent = {
      ...event,
      ...updates,
      id: eventId,
      creatorId: event.creatorId,
    };

    await kv.set(`event:${eventId}`, updatedEvent);
    return c.json({ success: true, event: updatedEvent });
  } catch (error) {
    console.error(`Error updating event: ${error}`);
    return c.json({ error: 'Failed to update event' }, 500);
  }
});

// Delete event
app.delete("/make-server-0bb28fd0/events/:id", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const eventId = c.req.param('id');
    const event = await kv.get(`event:${eventId}`);

    if (!event) {
      return c.json({ error: 'Event not found' }, 404);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (event.creatorId !== user.id && currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    await kv.del(`event:${eventId}`);
    return c.json({ success: true });
  } catch (error) {
    console.error(`Error deleting event: ${error}`);
    return c.json({ error: 'Failed to delete event' }, 500);
  }
});

// Register for event
app.post("/make-server-0bb28fd0/events/:id/register", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const eventId = c.req.param('id');
    const event = await kv.get(`event:${eventId}`);

    if (!event) {
      return c.json({ error: 'Event not found' }, 404);
    }

    if (!event.registeredUsers.includes(user.id)) {
      event.registeredUsers.push(user.id);
      await kv.set(`event:${eventId}`, event);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error(`Error registering for event: ${error}`);
    return c.json({ error: 'Failed to register' }, 500);
  }
});

// Get event stats
app.get("/make-server-0bb28fd0/events/:id/stats", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const eventId = c.req.param('id');
    const event = await kv.get(`event:${eventId}`);

    if (!event) {
      return c.json({ error: 'Event not found' }, 404);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (event.creatorId !== user.id && currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    // Get attendance records
    const attendanceRecords = await kv.getByPrefix(`attendance:${eventId}:`);

    return c.json({
      stats: {
        totalRegistered: event.registeredUsers.length,
        currentAttendees: event.currentAttendees,
        totalCheckIns: event.totalCheckIns,
        attendanceRecords,
      }
    });
  } catch (error) {
    console.error(`Error fetching event stats: ${error}`);
    return c.json({ error: 'Failed to fetch stats' }, 500);
  }
});

// ==================== NFC/QR SCAN ROUTES ====================

// Scan for event check-in/out
app.post("/make-server-0bb28fd0/scan/event", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const { eventId, scannedUserId } = await c.req.json();
    const scanner = await kv.get(`user:${user.id}`);
    const event = await kv.get(`event:${eventId}`);

    if (!event) {
      return c.json({ error: 'Event not found' }, 404);
    }

    // Only admins of the event can scan for attendance
    if (event.creatorId !== user.id && scanner.role !== 'system_manager') {
      return c.json({ error: 'Only event admins can scan for attendance' }, 403);
    }

    const attendanceKey = `attendance:${eventId}:${scannedUserId}`;
    let attendance = await kv.get(attendanceKey);

    if (!attendance) {
      // First check-in
      attendance = {
        eventId,
        userId: scannedUserId,
        checkIns: [],
        status: 'checked_in',
      };
      attendance.checkIns.push({
        type: 'check_in',
        scannerName: scanner.fullName,
        scannerId: user.id,
        timestamp: new Date().toISOString(),
      });
      event.currentAttendees++;
      event.totalCheckIns++;

      // Auto-join event forum
      const forum = await kv.get(`forum:${event.forumId}`);
      if (forum && !forum.members.includes(scannedUserId)) {
        forum.members.push(scannedUserId);
        await kv.set(`forum:${event.forumId}`, forum);
      }
    } else {
      // Toggle check-in/check-out
      if (attendance.status === 'checked_in') {
        attendance.status = 'checked_out';
        attendance.checkIns.push({
          type: 'check_out',
          scannerName: scanner.fullName,
          scannerId: user.id,
          timestamp: new Date().toISOString(),
        });
        event.currentAttendees--;
      } else {
        attendance.status = 'checked_in';
        attendance.checkIns.push({
          type: 'check_in',
          scannerName: scanner.fullName,
          scannerId: user.id,
          timestamp: new Date().toISOString(),
        });
        event.currentAttendees++;
        event.totalCheckIns++;
      }
    }

    await kv.set(attendanceKey, attendance);
    await kv.set(`event:${eventId}`, event);

    return c.json({
      success: true,
      attendance,
      currentAttendees: event.currentAttendees,
    });
  } catch (error) {
    console.error(`Error processing event scan: ${error}`);
    return c.json({ error: 'Failed to process scan' }, 500);
  }
});

// Scan user for networking
app.post("/make-server-0bb28fd0/scan/user", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const { scannedUserId } = await c.req.json();
    const scannedUser = await kv.get(`user:${scannedUserId}`);

    if (!scannedUser) {
      return c.json({ error: 'User not found' }, 404);
    }

    return c.json({ success: true, user: scannedUser });
  } catch (error) {
    console.error(`Error processing user scan: ${error}`);
    return c.json({ error: 'Failed to process scan' }, 500);
  }
});

// ==================== FORUM ROUTES ====================

// Get all forums
app.get("/make-server-0bb28fd0/forums", async (c) => {
  try {
    const forums = await kv.getByPrefix('forum:');
    return c.json({ forums });
  } catch (error) {
    console.error(`Error fetching forums: ${error}`);
    return c.json({ error: 'Failed to fetch forums' }, 500);
  }
});

// Create forum
app.post("/make-server-0bb28fd0/forums", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const forumData = await c.req.json();
    const forumId = generateId();

    const forum = {
      id: forumId,
      ...forumData,
      creatorId: user.id,
      moderators: [user.id],
      members: [user.id],
      posts: [],
      createdAt: new Date().toISOString(),
    };

    await kv.set(`forum:${forumId}`, forum);
    return c.json({ success: true, forum });
  } catch (error) {
    console.error(`Error creating forum: ${error}`);
    return c.json({ error: 'Failed to create forum' }, 500);
  }
});

// Get forum details
app.get("/make-server-0bb28fd0/forums/:id", async (c) => {
  try {
    const forumId = c.req.param('id');
    const forum = await kv.get(`forum:${forumId}`);
    
    if (!forum) {
      return c.json({ error: 'Forum not found' }, 404);
    }

    return c.json({ forum });
  } catch (error) {
    console.error(`Error fetching forum: ${error}`);
    return c.json({ error: 'Failed to fetch forum' }, 500);
  }
});

// Join forum
app.post("/make-server-0bb28fd0/forums/:id/join", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const forumId = c.req.param('id');
    const forum = await kv.get(`forum:${forumId}`);

    if (!forum) {
      return c.json({ error: 'Forum not found' }, 404);
    }

    if (!forum.members.includes(user.id)) {
      forum.members.push(user.id);
      await kv.set(`forum:${forumId}`, forum);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error(`Error joining forum: ${error}`);
    return c.json({ error: 'Failed to join forum' }, 500);
  }
});

// Get forum posts
app.get("/make-server-0bb28fd0/forums/:id/posts", async (c) => {
  try {
    const forumId = c.req.param('id');
    const posts = await kv.getByPrefix(`forumpost:${forumId}:`);
    
    return c.json({ posts });
  } catch (error) {
    console.error(`Error fetching forum posts: ${error}`);
    return c.json({ error: 'Failed to fetch posts' }, 500);
  }
});

// Create post in forum
app.post("/make-server-0bb28fd0/forums/:id/posts", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const forumId = c.req.param('id');
    const forum = await kv.get(`forum:${forumId}`);

    if (!forum) {
      return c.json({ error: 'Forum not found' }, 404);
    }

    if (!forum.members.includes(user.id)) {
      return c.json({ error: 'Must be a member to post' }, 403);
    }

    const postData = await c.req.json();
    const postId = generateId();

    const post = {
      id: postId,
      forumId,
      authorId: user.id,
      content: postData.content,
      likes: [],
      comments: [],
      createdAt: new Date().toISOString(),
    };

    await kv.set(`forumpost:${forumId}:${postId}`, post);
    return c.json({ success: true, post });
  } catch (error) {
    console.error(`Error creating forum post: ${error}`);
    return c.json({ error: 'Failed to create post' }, 500);
  }
});

// ==================== MESSAGE ROUTES ====================

// Get conversations
app.get("/make-server-0bb28fd0/conversations", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const allMessages = await kv.getByPrefix('message:');
    const conversations = new Map();

    for (const message of allMessages) {
      if (message.senderId === user.id || message.recipientId === user.id) {
        const otherUserId = message.senderId === user.id ? message.recipientId : message.senderId;
        if (!conversations.has(otherUserId)) {
          conversations.set(otherUserId, []);
        }
        conversations.get(otherUserId).push(message);
      }
    }

    const conversationList = Array.from(conversations.entries()).map(([userId, messages]) => ({
      userId,
      messages: messages.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
      lastMessage: messages[messages.length - 1],
    }));

    return c.json({ conversations: conversationList });
  } catch (error) {
    console.error(`Error fetching conversations: ${error}`);
    return c.json({ error: 'Failed to fetch conversations' }, 500);
  }
});

// Get messages with a user
app.get("/make-server-0bb28fd0/messages/:userId", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const otherUserId = c.req.param('userId');
    const allMessages = await kv.getByPrefix('message:');
    
    const messages = allMessages.filter((msg: any) => 
      (msg.senderId === user.id && msg.recipientId === otherUserId) ||
      (msg.senderId === otherUserId && msg.recipientId === user.id)
    ).sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    return c.json({ messages });
  } catch (error) {
    console.error(`Error fetching messages: ${error}`);
    return c.json({ error: 'Failed to fetch messages' }, 500);
  }
});

// Send message
app.post("/make-server-0bb28fd0/messages", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const { recipientId, content } = await c.req.json();
    const messageId = generateId();

    const message = {
      id: messageId,
      senderId: user.id,
      recipientId,
      content,
      read: false,
      createdAt: new Date().toISOString(),
    };

    await kv.set(`message:${messageId}`, message);
    return c.json({ success: true, message });
  } catch (error) {
    console.error(`Error sending message: ${error}`);
    return c.json({ error: 'Failed to send message' }, 500);
  }
});

// ==================== POST ROUTES ====================

// Get feed posts
app.get("/make-server-0bb28fd0/posts", async (c) => {
  try {
    const posts = await kv.getByPrefix('post:');
    const sortedPosts = posts.sort((a: any, b: any) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return c.json({ posts: sortedPosts });
  } catch (error) {
    console.error(`Error fetching posts: ${error}`);
    return c.json({ error: 'Failed to fetch posts' }, 500);
  }
});

// Create post
app.post("/make-server-0bb28fd0/posts", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const postData = await c.req.json();
    const postId = generateId();

    const post = {
      id: postId,
      authorId: user.id,
      content: postData.content,
      likes: [],
      comments: [],
      createdAt: new Date().toISOString(),
    };

    await kv.set(`post:${postId}`, post);
    return c.json({ success: true, post });
  } catch (error) {
    console.error(`Error creating post: ${error}`);
    return c.json({ error: 'Failed to create post' }, 500);
  }
});

// Like post
app.post("/make-server-0bb28fd0/posts/:id/like", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const postId = c.req.param('id');
    const post = await kv.get(`post:${postId}`);

    if (!post) {
      return c.json({ error: 'Post not found' }, 404);
    }

    const likeIndex = post.likes.indexOf(user.id);
    if (likeIndex > -1) {
      post.likes.splice(likeIndex, 1);
    } else {
      post.likes.push(user.id);
    }

    await kv.set(`post:${postId}`, post);
    return c.json({ success: true, post });
  } catch (error) {
    console.error(`Error liking post: ${error}`);
    return c.json({ error: 'Failed to like post' }, 500);
  }
});

// ==================== DOCUMENT ROUTES ====================

// Upload document
app.post("/make-server-0bb28fd0/documents", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const { fileName, fileData, fileType, documentType } = await c.req.json();
    const documentId = generateId();
    const bucketName = 'make-0bb28fd0-documents';

    // Decode base64 and upload to storage
    const fileBuffer = Uint8Array.from(atob(fileData), c => c.charCodeAt(0));
    const filePath = `${user.id}/${documentId}-${fileName}`;

    const { data: uploadData, error: uploadError } = await supabaseAdmin.storage
      .from(bucketName)
      .upload(filePath, fileBuffer, {
        contentType: fileType,
      });

    if (uploadError) {
      console.error(`Error uploading document: ${uploadError.message}`);
      return c.json({ error: uploadError.message }, 500);
    }

    // Create document record
    const document = {
      id: documentId,
      userId: user.id,
      fileName,
      filePath,
      fileType,
      documentType, // 'qualification', 'certificate', etc.
      verified: false,
      verifiedBy: null,
      verifiedAt: null,
      createdAt: new Date().toISOString(),
    };

    await kv.set(`document:${documentId}`, document);

    return c.json({ success: true, document });
  } catch (error) {
    console.error(`Error uploading document: ${error}`);
    return c.json({ error: 'Failed to upload document' }, 500);
  }
});

// Get pending documents (system manager only)
app.get("/make-server-0bb28fd0/documents/pending", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const documents = await kv.getByPrefix('document:');
    const pendingDocs = documents.filter((doc: any) => !doc.verified);

    return c.json({ documents: pendingDocs });
  } catch (error) {
    console.error(`Error fetching pending documents: ${error}`);
    return c.json({ error: 'Failed to fetch documents' }, 500);
  }
});

// Get document file URL
app.get("/make-server-0bb28fd0/documents/:id/file", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const documentId = c.req.param('id');
    const document = await kv.get(`document:${documentId}`);

    if (!document) {
      return c.json({ error: 'Document not found' }, 404);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (document.userId !== user.id && currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const bucketName = 'make-0bb28fd0-documents';
    const { data: signedUrlData, error: urlError } = await supabaseAdmin.storage
      .from(bucketName)
      .createSignedUrl(document.filePath, 3600); // 1 hour expiry

    if (urlError) {
      console.error(`Error creating signed URL: ${urlError.message}`);
      return c.json({ error: urlError.message }, 500);
    }

    return c.json({ url: signedUrlData.signedUrl });
  } catch (error) {
    console.error(`Error fetching document file: ${error}`);
    return c.json({ error: 'Failed to fetch file' }, 500);
  }
});

// Verify document (system manager only)
app.put("/make-server-0bb28fd0/documents/:id/verify", async (c) => {
  try {
    const user = await getAuthUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Not authenticated' }, 401);
    }

    const currentUser = await kv.get(`user:${user.id}`);
    if (currentUser.role !== 'system_manager') {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const documentId = c.req.param('id');
    const document = await kv.get(`document:${documentId}`);

    if (!document) {
      return c.json({ error: 'Document not found' }, 404);
    }

    const { verified } = await c.req.json();
    
    document.verified = verified;
    document.verifiedBy = user.id;
    document.verifiedAt = new Date().toISOString();

    await kv.set(`document:${documentId}`, document);

    // Update user profile with verified qualification
    if (verified) {
      const docOwner = await kv.get(`user:${document.userId}`);
      if (!docOwner.qualifications) {
        docOwner.qualifications = [];
      }
      docOwner.qualifications.push({
        documentId,
        fileName: document.fileName,
        documentType: document.documentType,
        verifiedAt: document.verifiedAt,
      });
      await kv.set(`user:${document.userId}`, docOwner);
    }

    return c.json({ success: true, document });
  } catch (error) {
    console.error(`Error verifying document: ${error}`);
    return c.json({ error: 'Failed to verify document' }, 500);
  }
});

// ==================== SEARCH ROUTES ====================

// Search events
app.get("/make-server-0bb28fd0/search/events", async (c) => {
  try {
    const query = c.req.query('q')?.toLowerCase() || '';
    const events = await kv.getByPrefix('event:');
    
    const filteredEvents = events.filter((event: any) => 
      event.name?.toLowerCase().includes(query) ||
      event.description?.toLowerCase().includes(query)
    );

    return c.json({ events: filteredEvents });
  } catch (error) {
    console.error(`Error searching events: ${error}`);
    return c.json({ error: 'Search failed' }, 500);
  }
});

// Search forums
app.get("/make-server-0bb28fd0/search/forums", async (c) => {
  try {
    const query = c.req.query('q')?.toLowerCase() || '';
    const forums = await kv.getByPrefix('forum:');
    
    const filteredForums = forums.filter((forum: any) => 
      forum.name?.toLowerCase().includes(query) ||
      forum.description?.toLowerCase().includes(query)
    );

    return c.json({ forums: filteredForums });
  } catch (error) {
    console.error(`Error searching forums: ${error}`);
    return c.json({ error: 'Search failed' }, 500);
  }
});

// ==================== INITIALIZATION ====================

// Initialize dummy data
async function initializeDummyData() {
  try {
    console.log('Checking for existing data...');
    const existingUsers = await kv.getByPrefix('user:');
    
    // Only initialize if no users exist
    if (existingUsers && existingUsers.length > 0) {
      console.log('Data already exists, skipping initialization');
      return;
    }

    console.log('Initializing dummy data...');
    
    // Create dummy users
    const dummyUsers = [
      {
        id: 'user-1',
        email: 'thabo@example.com',
        fullName: 'Thabo Ndlovu',
        role: 'user',
        biography: 'Software engineer with a passion for AI and machine learning. Based in Harare, Zimbabwe.',
        currentEmployment: 'Senior Developer at TechHub Zimbabwe',
        researchArea: 'Artificial Intelligence, Natural Language Processing',
        followers: ['user-2', 'user-3'],
        following: ['user-2'],
        qualifications: [],
        createdAt: new Date().toISOString(),
      },
      {
        id: 'user-2',
        email: 'nokuthula@example.com',
        fullName: 'Nokuthula Moyo',
        role: 'admin',
        biography: 'Event organizer and community builder. Love connecting people through technology events.',
        currentEmployment: 'Event Manager at Innovation Hub',
        researchArea: 'Community Development, Tech Education',
        followers: ['user-1', 'user-3'],
        following: ['user-1', 'user-3'],
        qualifications: [],
        createdAt: new Date().toISOString(),
      },
      {
        id: 'user-3',
        email: 'tendai@example.com',
        fullName: 'Tendai Chikwanda',
        role: 'user',
        biography: 'Data scientist exploring the intersection of data and social impact.',
        currentEmployment: 'Data Analyst at Analytics Co',
        researchArea: 'Data Science, Social Impact',
        followers: ['user-2'],
        following: ['user-1', 'user-2'],
        qualifications: [],
        createdAt: new Date().toISOString(),
      },
    ];

    for (const user of dummyUsers) {
      await kv.set(`user:${user.id}`, user);
    }

    // Create dummy events
    const dummyEvents = [
      {
        id: 'event-1',
        name: 'Zimbabwe Tech Summit 2026',
        description: 'Annual technology conference bringing together innovators, developers, and entrepreneurs from across Zimbabwe.',
        location: 'Harare International Conference Centre',
        startDate: '2026-03-15T09:00:00Z',
        endDate: '2026-03-17T17:00:00Z',
        organizerId: 'user-2',
        attendees: ['user-1', 'user-2', 'user-3'],
        checkedInAttendees: ['user-1'],
        forumId: 'forum-1',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'event-2',
        name: 'AI & Machine Learning Workshop',
        description: 'Hands-on workshop covering latest trends in AI and ML with practical applications.',
        location: 'Innovation Hub Bulawayo',
        startDate: '2026-03-22T10:00:00Z',
        endDate: '2026-03-22T16:00:00Z',
        organizerId: 'user-2',
        attendees: ['user-1', 'user-3'],
        checkedInAttendees: [],
        forumId: 'forum-2',
        createdAt: new Date().toISOString(),
      },
    ];

    for (const event of dummyEvents) {
      await kv.set(`event:${event.id}`, event);
    }

    // Create dummy forums
    const dummyForums = [
      {
        id: 'forum-1',
        name: 'Tech Summit 2026 Community',
        description: 'Discussion forum for Zimbabwe Tech Summit attendees and speakers.',
        creatorId: 'user-2',
        eventId: 'event-1',
        members: ['user-1', 'user-2', 'user-3'],
        createdAt: new Date().toISOString(),
      },
      {
        id: 'forum-2',
        name: 'AI Enthusiasts Zimbabwe',
        description: 'Connect with fellow AI and ML enthusiasts, share projects and ideas.',
        creatorId: 'user-1',
        eventId: 'event-2',
        members: ['user-1', 'user-2', 'user-3'],
        createdAt: new Date().toISOString(),
      },
      {
        id: 'forum-3',
        name: 'Startup Founders Network',
        description: 'A community for startup founders to share experiences and support each other.',
        creatorId: 'user-3',
        eventId: null,
        members: ['user-2', 'user-3'],
        createdAt: new Date().toISOString(),
      },
    ];

    for (const forum of dummyForums) {
      await kv.set(`forum:${forum.id}`, forum);
    }

    // Create dummy posts
    const dummyPosts = [
      {
        id: 'post-1',
        content: 'Excited to announce the Zimbabwe Tech Summit 2026! Registration is now open. Join us for three days of innovation, networking, and learning. 🚀',
        authorId: 'user-2',
        forumId: null,
        likes: ['user-1', 'user-3'],
        comments: ['comment-1'],
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'post-2',
        content: 'Just finished an amazing ML project using TensorFlow. The model achieved 95% accuracy! Would love to share insights at the upcoming workshop.',
        authorId: 'user-1',
        forumId: null,
        likes: ['user-2'],
        comments: [],
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'post-3',
        content: 'Looking forward to meeting everyone at the AI workshop next week! Bring your laptops and questions 💻',
        authorId: 'user-3',
        forumId: 'forum-2',
        likes: ['user-1', 'user-2'],
        comments: [],
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'post-4',
        content: 'What topics would you like to see covered at the Tech Summit? Drop your suggestions below! 👇',
        authorId: 'user-2',
        forumId: 'forum-1',
        likes: ['user-1'],
        comments: ['comment-2'],
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      },
    ];

    for (const post of dummyPosts) {
      await kv.set(`post:${post.id}`, post);
    }

    // Create dummy comments
    const dummyComments = [
      {
        id: 'comment-1',
        postId: 'post-1',
        content: 'Can\'t wait! Already registered.',
        authorId: 'user-1',
        createdAt: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'comment-2',
        postId: 'post-4',
        content: 'Would love to see more sessions on blockchain and Web3 technologies!',
        authorId: 'user-3',
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
      },
    ];

    for (const comment of dummyComments) {
      await kv.set(`comment:${comment.id}`, comment);
    }

    // Create dummy messages
    const dummyConversations = [
      {
        id: 'conv-1',
        participants: ['user-1', 'user-2'],
        lastMessage: 'Thanks for the info about the summit!',
        lastMessageAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'conv-2',
        participants: ['user-1', 'user-3'],
        lastMessage: 'Let\'s collaborate on that ML project',
        lastMessageAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
      },
    ];

    for (const conv of dummyConversations) {
      await kv.set(`conversation:${conv.id}`, conv);
    }

    const dummyMessages = [
      {
        id: 'msg-1',
        conversationId: 'conv-1',
        senderId: 'user-1',
        recipientId: 'user-2',
        content: 'Hi Nokuthula! Are there still speaker slots available for the summit?',
        read: true,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'msg-2',
        conversationId: 'conv-1',
        senderId: 'user-2',
        recipientId: 'user-1',
        content: 'Hi Thabo! Yes, we have a few slots left. What topic would you like to present on?',
        read: true,
        createdAt: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'msg-3',
        conversationId: 'conv-1',
        senderId: 'user-1',
        recipientId: 'user-2',
        content: 'I\'d love to do a talk on NLP applications in local languages. Thanks for the info about the summit!',
        read: true,
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'msg-4',
        conversationId: 'conv-2',
        senderId: 'user-3',
        recipientId: 'user-1',
        content: 'Saw your post about the ML project. Very impressive results!',
        read: true,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'msg-5',
        conversationId: 'conv-2',
        senderId: 'user-1',
        recipientId: 'user-3',
        content: 'Thanks! Let\'s collaborate on that ML project',
        read: false,
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
      },
    ];

    for (const msg of dummyMessages) {
      await kv.set(`message:${msg.id}`, msg);
    }

    console.log('Dummy data initialized successfully!');
  } catch (error) {
    console.error(`Error initializing dummy data: ${error}`);
  }
}

// Call initialization
initializeDummyData();

Deno.serve(app.fetch);